<?php
/**
 * Template for AlightMotion Premium APK
 * Generated from: page.html
 */

get_header(); ?>

<div class="page-content">
    
</div>

<?php get_footer(); ?>