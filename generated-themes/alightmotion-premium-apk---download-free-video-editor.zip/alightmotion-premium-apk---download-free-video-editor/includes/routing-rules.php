<?php
/**
 * Custom routing rules for converted pages
 * Maintains original URL structure from HTML website
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add custom rewrite rules
 */
function converted_theme_add_rewrite_rules() {
    add_rewrite_rule('^page/?$', 'index.php?pagename=page', 'top');
    add_rewrite_rule('^blog/?$', 'index.php?pagename=blog', 'top');
    add_rewrite_rule('^privacy-policy/?$', 'index.php?pagename=privacy-policy', 'top');
    add_rewrite_rule('^terms-of-service/?$', 'index.php?pagename=terms-of-service', 'top');
    add_rewrite_rule('^dmca/?$', 'index.php?pagename=dmca', 'top');
    
    // Flush rewrite rules on theme activation
    flush_rewrite_rules();
}
add_action('init', 'converted_theme_add_rewrite_rules');

/**
 * Add query vars
 */
function converted_theme_add_query_vars($vars) {
    $vars[] = 'custom_page';
    return $vars;
}
add_filter('query_vars', 'converted_theme_add_query_vars');

/**
 * Template redirect for custom pages
 */
function converted_theme_template_redirect() {
    global $wp_query;
    
    if (is_page() && !is_front_page()) {
        $page_template = get_page_template_slug();
        if ($page_template) {
            $template_file = locate_template($page_template);
            if ($template_file) {
                include $template_file;
                exit;
            }
        }
    }
}
add_action('template_redirect', 'converted_theme_template_redirect');
?>