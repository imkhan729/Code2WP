<?php
/**
 * Template for Terms of Service
 * Generated from: terms-of-service.html
 */

get_header(); ?>

<div class="page-content">
    
</div>

<?php get_footer(); ?>