<?php
/**
 * Template for Privacy Policy
 * Generated from: privacy-policy.html
 */

get_header(); ?>

<div class="page-content">
    
</div>

<?php get_footer(); ?>