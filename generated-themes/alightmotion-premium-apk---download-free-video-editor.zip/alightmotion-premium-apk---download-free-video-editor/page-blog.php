<?php
/**
 * Template for Blog
 * Generated from: blog.html
 */

get_header(); ?>

<div class="page-content">
    
</div>

<?php get_footer(); ?>