<?php
/**
 * Template for DMCA
 * Generated from: dmca.html
 */

get_header(); ?>

<div class="page-content">
    
</div>

<?php get_footer(); ?>