<?php get_header(); ?>

<div class="blog-content">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <div class="entry-meta">
                    <time class="entry-date"><?php echo get_the_date(); ?></time>
                    <span class="entry-author"><?php the_author(); ?></span>
                </div>
            </header>
            
            <div class="entry-content">
                
                <?php the_content(); ?>
            </div>
            
            <footer class="entry-footer">
                <?php the_tags('<div class="tags">', ', ', '</div>'); ?>
                <?php the_category(', '); ?>
            </footer>
        </article>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>