<?php get_header(); ?>

<div class="page-content">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>
            
            
<div>
    <h1>Example Domain</h1><div class="entry-content"><!--?php the_content(); ?--></div>
    <p>This domain is for use in illustrative examples in documents. You may use this
    domain in literature without prior coordination or asking for permission.</p>
    <p><a href="https://www.iana.org/domains/example">More information...</a></p>
</div>



        </article>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>