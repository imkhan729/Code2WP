<?php get_header(); ?>

<div class="error-404 not-found">
    <header class="page-header">
        <h1 class="page-title">Example Domain - Page Not Found</h1>
    </header>
    
    <div class="page-content">
        <p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
        
        <?php get_search_form(); ?>
        
        <div class="recent-posts">
            <h2>Recent Posts</h2>
            <?php
            $recent_posts = wp_get_recent_posts(array(
                'numberposts' => 5,
                'post_status' => 'publish'
            ));
            foreach ($recent_posts as $post) :
                ?>
                <p><a href="<?php echo get_permalink($post['ID']); ?>"><?php echo $post['post_title']; ?></a></p>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php get_footer(); ?>