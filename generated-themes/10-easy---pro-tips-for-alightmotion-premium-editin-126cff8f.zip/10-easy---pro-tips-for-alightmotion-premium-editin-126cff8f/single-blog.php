<?php
/**
 * Single post template for Blog - AlightMotion Premium APK | Video Editing Tips & Guides
 * Generated from: alight-motion-website/alight-motion-website/blog.html
 */

get_header(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-meta">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
            <span class="author"><?php the_author(); ?></span>
        </div>
    </header>

    <div class="entry-content">
        
                        <div class="card-media">
                            <img class="cover" src="images/visual-effects.webp" alt="How to use AlightMotion presets">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Guide</span>
                            <span class="badge badge-outline">Presets</span>
                            <span class="blog-date">Aug 12, 2025</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>How to Use AlightMotion Presets (Step-by-Step)</h2>
                                <p>Learn a fast preset workflow, how to stack looks, and how to make reusable custom presets for consistent results.</p>
                                 <a class="btn btn-secondary" href="/blog/how-to-use-presets-in-alightmotion">Read Article</a>
                            </div>
                        </div>
                    
        <?php the_content(); ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<p>Tags: ', ', ', '</p>'); ?>
        <?php the_category(); ?>
    </footer>
</article>

<?php get_footer(); ?>