<?php
/**
 * Template for AlightMotion Premium APK - Download Free Video Editor
 * Generated from: alight-motion-website/alight-motion-website/index.html
 */

get_header(); ?>

<div class="page-content">
    
    <!-- Header -->
    

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-text">
                    <h1>AlightMotion Premium APK</h1>
                    <h2>Professional Video Editing &amp; Animation</h2>
                    <p>Create stunning videos and animations with the most powerful mobile video editor. Get access to premium features, <a href="#features">visual effects</a>, and unlimited creativity without watermarks. Jump to <a href="#installation">installation</a> or <a href="#faq">FAQ</a>.</p>
                    <div class="hero-buttons">
                        <a href="#download" class="btn btn-primary">Download Now</a>
                        <a href="#features" class="btn btn-secondary">Learn More</a>
                    </div>
    <!-- About Section (Redesigned) -->
    <section id="about" class="about">
        <div class="container">
            <div class="about-card">
                <div class="about-header">
                    <div class="about-badges">
                        <span class="badge badge-primary">Mod APK</span>
                        <span class="badge badge-success">v5.0.281</span>
                        <span class="badge badge-outline">Android 7.0+</span>
                    </div>
                    <h2 class="about-title">About AlightMotion Mod APK</h2>
                    <p class="about-subtitle">Professional video editing and animation app with premium features unlocked</p>
                </div>
                
                <div class="about-layout">
                    <div class="about-content">
                        <div class="about-description">
                            <h3>What's New in This Version</h3>
                            <p>The latest build focuses on motion graphics, video editing, animation, and vector design with an emphasis on ease of use and performance. Experience professional-grade tools with enhanced keyframe animation, motion blur, timing curves, blending modes, and extensive fonts/effects library.</p>
                        </div>
                        
                        <div class="about-features">
                            <h3>Key Features</h3>
                            <div class="features-grid-mini">
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>Unlocked effects and fonts</span>
                                </div>
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>No ads and no watermark</span>
                                </div>
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>Chroma key and XML preset support</span>
                                </div>
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>Vector graphics and new export formats</span>
                                </div>
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>Real‑time preview and HD output</span>
                                </div>
                                <div class="feature-item">
                                    <div class="feature-icon">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                                    </div>
                                    <span>Multi-layer support</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="about-cta">
                            <a href="#download" class="btn btn-primary">Download APK</a>
                            <a href="#features" class="btn btn-secondary">View All Features</a>
                        </div>
                    </div>
                    
                    <div class="about-image">
                        <div class="image-container">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/Presets-in-Alight-Motion.webp" alt="AlightMotion Presets" class="about-mockup" loading="lazy">
                            <div class="image-overlay">
                                <span class="overlay-text">Premium Features Unlocked</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
                    <div class="hero-stats">
                        <div class="stat">
                            <span class="stat-number">10M+</span>
                            <span class="stat-label">Downloads</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">4.8★</span>
                            <span class="stat-label">Rating</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">1000+</span>
                            <span class="stat-label">Effects</span>
                        </div>
                    </div>
                </div>
                <div class="hero-image">
                    <picture>
                        <source srcset="images/Alightmotion-Hero-image.webp" type="image/webp">
                        <source srcset="images/Alightmotion-Hero-image.webp" type="image/webp">
                        <source srcset="images/Alightmotion-Hero-image.png" type="image/png">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Alightmotion Hero image.png" alt="AlightMotion App Interface" class="hero-mockup">
                    </picture>
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Presets-in-Alight-Motion.webp" alt="AlightMotion Presets" class="hero-below-image" loading="lazy">
                </div>
            </div>
        </div>
    </section>

    

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <div class="section-header">
                <h2>Powerful Features</h2>
                <p>Everything you need to create professional videos and animations</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2L2 7V10C2 16 6 20.5 12 22C18 20.5 22 16 22 10V7L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </div>
                    <h3>Multi-Layer Support</h3>
                    <p>Work with unlimited layers to create complex animations and video compositions with professional precision.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M14.5 4H20.5C21.6 4 22.5 4.9 22.5 6V18C22.5 19.1 21.6 20 20.5 20H14.5V4Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M9.5 4H3.5C2.4 4 1.5 4.9 1.5 6V18C1.5 19.1 2.4 20 3.5 20H9.5V4Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>1000+ Visual Effects</h3>
                    <p>Access a massive library of visual effects, transitions, filters, and color correction tools to enhance your videos.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M8 12L10.5 14.5L16 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </div>
                    <h3>Vector Graphics</h3>
                    <p>Create and edit scalable vector graphics directly in your mobile device for crisp, professional animations.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 12L11 14L15 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Frame-by-Frame Animation</h3>
                    <p>Create smooth animations with precise frame-by-frame control. Customize every element and movement individually.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21 15V19C21 20.1 20.1 21 19 21H5C3.9 21 3 20.1 3 19V15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M7 10L12 15L17 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M12 15V3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </div>
                    <h3>No Watermark</h3>
                    <p>Export your videos in high quality without any watermarks. Perfect for professional use and social media.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 6V12L16 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Real-time Preview</h3>
                    <p>See your edits instantly with real-time preview functionality. No waiting, no rendering delays during editing.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Download Section -->
    <section id="download" class="download">
        <div class="container">
            <div class="download-content">
                <div class="download-info">
                    <h2>Download AlightMotion Premium APK</h2>
                    <p>Get the latest version with all premium features unlocked. Safe, secure, and regularly updated. For additional mirrors and versions, visit our recommended resource.</p>
                    
                    <div class="app-details">
                        <div class="detail-item">
                            <span class="detail-label">Version:</span>
                            <span class="detail-value">v5.0.272</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Size:</span>
                            <span class="detail-value">106MB</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Requirements:</span>
                            <span class="detail-value">Android 7.0+</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Last Updated:</span>
                            <span class="detail-value">December 2024</span>
                        </div>
                    </div>
                    
                    <div class="download-buttons">
                        <a href="https://www.4sync.com/web/directDownload/MFCNVA4T/J6T703a4.a15f84b03e8e89bb7b692a7ae6c19ade" class="btn btn-download external-link highlight-link">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21 15V19C21 20.1 20.1 21 19 21H5C3.9 21 3 20.1 3 19V15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M7 10L12 15L17 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M12 15V3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            Download APK 
                        </a>
                        <a href="#installation" class="btn btn-secondary">Installation Guide</a>
                    </div>
                </div>
                <div class="download-image">
                    <picture>
                        <source srcset="images/Alightmotion download.webp" type="image/webp">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/Alightmotion download.png" alt="Download AlightMotion" class="download-img" loading="lazy">
                    </picture>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="pricing">
        <div class="container">
            <div class="section-header">
                <h2>AlightMotion Subscription Prices</h2>
                <p>Official Pro subscription pricing for comparison.</p>
            </div>
            <div class="features-grid">
                <div class="feature-card plan-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 22C17.523 22 22 17.523 22 12C22 6.477 17.523 2 12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M8 12L11 15L16 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </div>
                    <h3>Weekly</h3>
                    <p class="price-large">$4.99 <span class="period">/week</span></p>
                    <p class="muted">All effects and fonts, no watermark, HD export.</p>
                    <a href="#download" class="btn btn-secondary">Choose Weekly</a>
                </div>
                <div class="feature-card plan-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 6H21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M3 12H21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M3 18H21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                        </svg>
                    </div>
                    <h3>Monthly</h3>
                    <p class="price-large">$6.99 <span class="period">/month</span></p>
                    <p class="muted">Unlimited layers, full effects library, real‑time preview.</p>
                    <a href="#download" class="btn btn-primary">Choose Monthly</a>
                </div>
                <div class="feature-card plan-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2V12L18 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            <path d="M12 22C17.523 22 22 17.523 22 12C22 6.477 17.523 2 12 2C6.477 2 2 6.477 2 12C2 17.523 6.477 22 12 22Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Yearly</h3>
                    <p class="price-large">$28.99 <span class="period">/year</span></p>
                    <p class="muted">Best value. All Pro features, priority updates and sync.</p>
                    <a href="#download" class="btn btn-download">Choose Yearly</a>
                </div>
            </div>
        </div>
    </section>

    <!-- System Requirements Section -->
    <section id="requirements" class="requirements">
        <div class="container">
            <div class="section-header">
                <h2>System Requirements</h2>
                <p>Recommended device specs for smooth editing.</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 5H21V19H3V5Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M8 21H16" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                        </svg>
                    </div>
                    <h3>Operating System</h3>
                    <p class="muted">Android 7.0 and up for best compatibility.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 4H20V20H4V4Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M4 10H20" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Storage</h3>
                    <p class="muted">106–159 MB free space for install and caching.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 7H20V17H4V7Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M8 7V17" stroke="currentColor" stroke-width="2"></path>
                            <path d="M16 7V17" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Memory</h3>
                    <p class="muted">2 GB RAM minimum, 3 GB+ recommended.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M7 12H17" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                        </svg>
                    </div>
                    <h3>Processor</h3>
                    <p class="muted">Modern Snapdragon/Exynos/Kirin CPU recommended.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Troubleshooting Section -->
    <section id="troubleshooting" class="troubleshooting">
        <div class="container">
            <div class="section-header">
                <h2>Common Issues &amp; Fixes</h2>
                <p>Quick solutions to the most reported problems.</p>
            </div>
            <div class="features-grid">
                <div class="feature-card issue-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 9V13" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M12 17H12.01" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M12 2L2 7V17L12 22L22 17V7L12 2Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>Unable to Download</h3>
                    <ul class="card-list">
                        <li>Enable Unknown Sources: Settings → Security.</li>
                        <li>Ensure stable internet and free storage.</li>
                        <li>Retry from a trusted mirror.</li>
                    </ul>
                </div>
                <div class="feature-card issue-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 7H15" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M12 2V4" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                            <path d="M4 10H20V20H4V10Z" stroke="currentColor" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3>App Crashes on Launch</h3>
                    <ul class="card-list">
                        <li>Clear cache and delete corrupted files.</li>
                        <li>Reboot device; update GPU drivers if available.</li>
                        <li>Reinstall latest build.</li>
                    </ul>
                </div>
                <div class="feature-card issue-card">
                    <div class="feature-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 4H20V16H4V4Z" stroke="currentColor" stroke-width="2"></path>
                            <path d="M4 20H20" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
                        </svg>
                    </div>
                    <h3>Lag During Editing</h3>
                    <ul class="card-list">
                        <li>Close background apps and free storage.</li>
                        <li>Lower preview quality; export at target resolution.</li>
                        <li>Use devices with 3 GB+ RAM.</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Installation Guide -->
    <section id="installation" class="installation">
        <div class="container">
            <div class="section-header">
                <h2>Installation Guide</h2>
                        <p>Follow these simple steps to install AlightMotion Premium on your device</p>
            </div>
            
            <div class="installation-tabs">
                <div class="tab-buttons">
                    <button class="tab-button active" data-tab="android">Android</button>
                    <button class="tab-button" data-tab="ios">iOS</button>
                    <button class="tab-button" data-tab="pc">PC</button>
                </div>
                
                <div class="tab-content">
                    <div id="android" class="tab-panel active">
                        <div class="steps">
                            <div class="step">
                                <div class="step-number">1</div>
                                <div class="step-content">
                                    <h3>Enable Unknown Sources</h3>
                                    <p>Go to Settings &gt; Security &gt; Enable "Unknown Sources" to allow APK installations.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">2</div>
                                <div class="step-content">
                                    <h3>Download APK File</h3>
                                    <p>Click the download button above to get the AlightMotion Premium APK file.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">3</div>
                                <div class="step-content">
                                    <h3>Install APK</h3>
                                    <p>Locate the downloaded file and tap to install. Follow the on-screen prompts.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">4</div>
                                <div class="step-content">
                                    <h3>Launch &amp; Enjoy</h3>
                                    <p>Open AlightMotion and start creating amazing videos with all premium features unlocked!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="ios" class="tab-panel">
                        <div class="steps">
                            <div class="step">
                                <div class="step-number">1</div>
                                <div class="step-content">
                                    <h3>Install AltStore</h3>
                                    <p>Download and install AltStore on your iOS device for sideloading apps.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">2</div>
                                <div class="step-content">
                                    <h3>Download IPA File</h3>
                                    <p>Get the AlightMotion Premium IPA file compatible with iOS devices.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">3</div>
                                <div class="step-content">
                                    <h3>Install via AltStore</h3>
                                    <p>Use AltStore to install the IPA file on your iOS device.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">4</div>
                                <div class="step-content">
                                    <h3>Trust Certificate</h3>
                                    <p>Go to Settings &gt; General &gt; Device Management and trust the certificate.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="pc" class="tab-panel">
                        <div class="steps">
                            <div class="step">
                                <div class="step-number">1</div>
                                <div class="step-content">
                                    <h3>Install Android Emulator</h3>
                                    <p>Download and install BlueStacks or any Android emulator on your PC.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">2</div>
                                <div class="step-content">
                                    <h3>Download APK</h3>
                                    <p>Get the AlightMotion Premium APK file on your computer.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">3</div>
                                <div class="step-content">
                                    <h3>Install in Emulator</h3>
                                    <p>Drag and drop the APK file into the emulator or use the install APK option.</p>
                                </div>
                            </div>
                            <div class="step">
                                <div class="step-number">4</div>
                                <div class="step-content">
                                    <h3>Start Creating</h3>
                                    <p>Launch AlightMotion in the emulator and enjoy video editing on PC!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Pros and Cons Section -->
    <section class="pros-cons">
        <div class="container">
            <div class="section-header">
                <h2>Pros &amp; Cons</h2>
                <p>Everything you need to know before downloading</p>
            </div>
            
            <div class="pros-cons-grid">
                <div class="pros">
                    <h3><span class="icon-check">✓</span> Pros</h3>
                    <ul>
                        <li>Easy to use interface with intuitive controls</li>
                        <li>All premium features unlocked for free</li>
                        <li>No watermark on exported videos</li>
                        <li>Multi-layer support for complex projects</li>
                        <li>XML support for advanced customization</li>
                        <li>No annoying advertisements</li>
                        <li>Regular feature updates</li>
                        <li>Professional-grade visual effects</li>
                    </ul>
                </div>
                
                <div class="cons">
                    <h3><span class="icon-cross">✗</span> Cons</h3>
                    <ul>
                        <li>Free version has watermark (not in Pro)</li>
                        <li>Keyframes may cause freezing sometimes</li>
                        <li>No live app updates in modded version</li>
                        <li>Requires Android 7.0 or higher</li>
                        <li>Large file size (106MB)</li>
                        <li>May drain battery quickly during intensive editing</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- App Info Section -->
    <section id="app-info" class="app-info">
        <div class="container">
            <div class="section-header">
                <h2>App Info</h2>
                <p>Key technical details at a glance</p>
            </div>
            <div class="appinfo-card">
                <dl class="info-grid">
                    <div class="info-row"><dt>App Name</dt><dd>AlightMotion Mod Apk</dd></div>
                    <div class="info-row"><dt>Version</dt><dd>5.0.281</dd></div>
                    <div class="info-row"><dt>Mod Features</dt><dd>Pro Unlocked, Premium App</dd></div>
                    <div class="info-row"><dt>Developer</dt><dd><a href="https://alightmotion.com/" target="_blank" rel="noopener" class="external-link">Alight Creative</a></dd></div>
                    <div class="info-row"><dt>Released On</dt><dd>Aug 5, 2018</dd></div>
                    <div class="info-row"><dt>File Type</dt><dd>Mod APK</dd></div>
                    <div class="info-row"><dt>Compulsory</dt><dd>Android 7.0 or up</dd></div>
                    <div class="info-row"><dt>Supported</dt><dd>Android</dd></div>
                    <div class="info-row"><dt>Rating</dt><dd>4.8</dd></div>
                    <div class="info-row"><dt>Category</dt><dd>Video Editing App</dd></div>
                    <div class="info-row"><dt>Download</dt><dd>100M+</dd></div>
                    <div class="info-row"><dt>Chipset Requirement</dt><dd>Qualcomm Snapdragon, Kirin HiSilicon, Samsung Exynos, Intel Atom, Tegra</dd></div>
                    <div class="info-row"><dt>Size</dt><dd>106 MB</dd></div>
                    <div class="info-row"><dt>Price</dt><dd>Free</dd></div>
                    <div class="info-row"><dt>Minimum RAM Requirement</dt><dd>1.5 GB (2.0 GB recommended or higher)</dd></div>
                </dl>
            </div>
        </div>
    </section>

    <!-- Showcase Carousel (placeholder images) -->
    <section class="showcase-carousel">
        <div class="container">
            <div class="section-header">
                <h2>AlightMotion APK Screenshots</h2>
            </div>
            <div class="showcase-wrapper">
                <button class="showcase-nav prev" aria-label="Previous">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </button>
                <div class="showcase-viewport">
                    <div class="showcase-track">
                        <div class="showcase-slide"><div class="showcase-card"><h4>Color Adjustment</h4><img src="<?php echo get_template_directory_uri(); ?>/images/color-adjustment.webp" alt="Color Adjustment" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Export in Many Formats</h4><img src="<?php echo get_template_directory_uri(); ?>/images/export-in-many-formats.webp" alt="Export in Many Formats" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Fonts</h4><img src="<?php echo get_template_directory_uri(); ?>/images/fonts.webp" alt="Fonts" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Keyframe Animation</h4><img src="<?php echo get_template_directory_uri(); ?>/images/keyframe-animation.webp" alt="Keyframe Animation" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Parenting</h4><img src="<?php echo get_template_directory_uri(); ?>/images/parenting.webp" alt="Parenting" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Vector Graphics</h4><img src="<?php echo get_template_directory_uri(); ?>/images/vector-graphics.webp" alt="Vector Graphics" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Visual Effects</h4><img src="<?php echo get_template_directory_uri(); ?>/images/visual-effects.webp" alt="Visual Effects" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Aspect Ratio</h4><img src="<?php echo get_template_directory_uri(); ?>/images/aspect-ratio-576x1024.webp" alt="Aspect Ratio" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Blending Modes</h4><img src="<?php echo get_template_directory_uri(); ?>/images/blending-modes-576x1024.webp" alt="Blending Modes" loading="lazy"></div></div>
                        <div class="showcase-slide"><div class="showcase-card"><h4>Blending Modes</h4><img src="<?php echo get_template_directory_uri(); ?>/images/blending-modes-576x1024 (1).webp" alt="Blending Modes" loading="lazy"></div></div>
                    </div>
                </div>
                <button class="showcase-nav next" aria-label="Next">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </button>
            </div>
            <div class="showcase-dots" aria-label="Carousel Pagination"></div>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews">
        <div class="container">
            <div class="section-header">
                <h2>User Reviews</h2>
                <p>What our users are saying about AlightMotion Premium</p>
            </div>
            
            <div class="reviews-grid">
                <div class="review-card">
                    <div class="review-rating">
                        <span class="stars">★★★★★</span>
                        <span class="rating-text">5.0</span>
                    </div>
                    <p class="review-text">"This APK has revolutionized my video editing workflow. The premium features are incredible and the interface is so intuitive. Highly recommend!"</p>
                    <div class="reviewer">
                        <div class="reviewer-avatar">JD</div>
                        <div class="reviewer-info">
                            <span class="reviewer-name">John Doe</span>
                            <span class="reviewer-title">Content Creator</span>
                        </div>
                    </div>
                </div>
                
                <div class="review-card">
                    <div class="review-rating">
                        <span class="stars">★★★★★</span>
                        <span class="rating-text">5.0</span>
                    </div>
                    <p class="review-text">"Amazing app! The visual effects library is extensive and the multi-layer support makes it perfect for professional projects. No watermark is a huge plus!"</p>
                    <div class="reviewer">
                        <div class="reviewer-avatar">SM</div>
                        <div class="reviewer-info">
                            <span class="reviewer-name">Sarah Miller</span>
                            <span class="reviewer-title">Video Editor</span>
                        </div>
                    </div>
                </div>
                
                <div class="review-card">
                    <div class="review-rating">
                        <span class="stars">★★★★★</span>
                        <span class="rating-text">5.0</span>
                    </div>
                    <p class="review-text">"Best mobile video editor I've ever used. The frame-by-frame animation feature is outstanding. Creates Hollywood-level animations on mobile!"</p>
                    <div class="reviewer">
                        <div class="reviewer-avatar">MJ</div>
                        <div class="reviewer-info">
                            <span class="reviewer-name">Mike Johnson</span>
                            <span class="reviewer-title">Animator</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq">
        <div class="container">
            <div class="section-header">
                <h2>Frequently Asked Questions</h2>
                <p>Find answers to common questions about AlightMotion Premium</p>
            </div>
            
            <div class="faq-list">
                <div class="faq-item">
                    <button class="faq-question">
                        <span>Is AlightMotion Premium APK safe to download?</span>
                        <svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, our APK file is completely safe and virus-free. We regularly scan all files for malware and ensure they're safe for download. The APK is sourced from trusted developers.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>What's the difference between free and Pro version?</span>
                        <svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </button>
                    <div class="faq-answer">
                        <p>The Pro version includes all premium features unlocked, no watermark on exports, unlimited layers, access to all visual effects, and no advertisements. The free version has limitations and watermarks.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>Can I use this for commercial projects?</span>
                        <svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </button>
                    <div class="faq-answer">
                        <p>Yes, you can use AlightMotion Premium for commercial projects. Since there's no watermark, your videos will look completely professional and suitable for client work or business use.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>How often is the app updated?</span>
                        <svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </button>
                    <div class="faq-answer">
                        <p>We regularly update the APK with the latest version from the developers. Updates typically include new features, bug fixes, and performance improvements. Check back monthly for updates.</p>
                    </div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">
                        <span>What devices are supported?</span>
                        <svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </button>
                    <div class="faq-answer">
                        <p>AlightMotion Premium works on Android devices running Android 7.0 (API level 24) or higher. For optimal performance, we recommend devices with at least 3GB RAM and a modern processor.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Resources Section (Internal & External Links) -->
    <section id="resources" class="resources">
        <div class="container">
            <div class="section-header">
                <h2>Resources</h2>
                <p>Helpful links for learning and downloads.</p>
            </div>
            <div class="resource-links">
                <a href="#features" class="chip">Features</a>
                <a href="#installation" class="chip">Installation</a>
                <a href="#faq" class="chip">FAQ</a>
                <a href="#pricing" class="chip">Pricing</a>
                <a href="#requirements" class="chip">Requirements</a>
                <a href="https://alightmotionlab.com/" target="_blank" rel="nofollow noopener" class="chip external-link highlight-link">AlightMotionLab Home</a>
                <a href="https://alightmotionlab.com/for-pc" target="_blank" rel="nofollow noopener" class="chip external-link">For PC</a>
                <a href="https://alightmotionlab.com/for-ios" target="_blank" rel="nofollow noopener" class="chip external-link">For iOS</a>
                <a href="https://alightmotionlab.com/comparison" target="_blank" rel="nofollow noopener" class="chip external-link">Comparison</a>
                <a href="https://alightmotionlab.com/old-versions" target="_blank" rel="nofollow noopener" class="chip external-link">Old Versions</a>
                <a href="https://alightmotionlab.com/blog" target="_blank" rel="nofollow noopener" class="chip external-link">Blog</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    

    <!-- JavaScript -->
    <script src="script.js"></script>



</div>

<?php get_footer(); ?>