<?php
/**
 * Template for How to Add Text in AlightMotion – Easy Guide for Beginners (2024)
 * Generated from: alight-motion-website/alight-motion-website/blog/how-to-add-text-in-alightimotion.html
 */

get_header(); ?>

<div class="page-content">
    
  

  <main>
    <section class="hero" style="padding: 120px 0 60px;">
      <div class="container">
        <div class="section-header" style="text-align:center;">
          <h1>How to Add Text in AlightMotion – A Simple Guide for Beginners</h1>
          <p>Create titles, captions, and animated text that look professional on mobile</p>
        </div>
      </div>
    </section>

    <section class="about" style="padding: 0 0 80px;">
      <div class="container">
        <div class="about-card">
          <div class="back-row" style="margin-bottom:12px;">
            <a class="btn btn-secondary" href="<?php echo home_url('//blog/'); ?>">← Back to Blog</a>
          </div>
          <img class="cover" src="<?php echo get_template_directory_uri(); ?>/../images/fonts.webp" alt="Add text in AlightMotion" style="width:100%;border-radius:14px;margin-bottom:1.25rem;" loading="lazy">
          <div class="about-content">
            <div class="about-description">
              <div class="blog-badges">
                <span class="badge badge-primary">Guide</span>
                <span class="badge badge-outline">Text</span>
                <span class="blog-date">Updated — 2024</span>
              </div>

              <p>Want your videos to look clean, modern, and scroll‑stopping? Adding <strong>text</strong> in <strong>AlightMotion</strong> is one of the fastest ways to level up. This beginner‑friendly guide shows how to add, style, and animate text — with tips to keep everything crisp on mobile screens.</p>

              <div class="resource-links" style="margin: 1rem 0 2rem;">
                <a class="chip" href="#what-is-am">What Is AlightMotion?</a>
                <a class="chip" href="#why-text">Why Add Text</a>
                <a class="chip" href="#steps">Add Text (Steps)</a>
                <a class="chip" href="#style">Style Like a Pro</a>
                <a class="chip" href="#animate">Animate Text</a>
                <a class="chip" href="#tips">Top Tips</a>
                <a class="chip" href="#faq">FAQs</a>
              </div>

              <h2 id="what-is-am">What Is AlightMotion?</h2>
              <p><strong>AlightMotion</strong> is a powerful mobile editor for motion graphics, titles, and effects — like having a mini studio in your pocket. You can design animated text, apply looks, and export for TikTok, Reels, and YouTube. Learn more on the <a href="https://www.alightmotion.com/" target="_blank" rel="nofollow noopener" class="external-link highlight-link">official site</a>.</p>

              <h2 id="why-text">Why Add Text to Your Videos?</h2>
              <ul class="about-feature-list">
                <li><span><strong>Accessibility</strong>: captions help viewers who can’t play audio.</span></li>
                <li><span><strong>Professional polish</strong>: titles and lower‑thirds elevate your edit.</span></li>
                <li><span><strong>Attention‑grabbing</strong>: motion titles stop the scroll.</span></li>
                <li><span><strong>Social‑ready</strong>: bold, readable text performs better on mobile feeds.</span></li>
              </ul>

              <h2 id="steps">Step‑by‑Step: How to Add Text</h2>
              <ol class="about-feature-list" style="list-style: decimal; padding-left: 1.25rem;">
                <li><span><strong>Open your project</strong>: New Project → import a clip via the <em>+</em> button.</span></li>
                <li><span><strong>Tap Text</strong>: choose the <strong>T</strong> icon and select <strong>Add Text</strong>.</span></li>
                <li><span><strong>Type your message</strong>: titles, captions, or callouts — you can edit later.</span></li>
                <li><span><strong>Position and resize</strong>: drag to place; pinch to scale.</span></li>
              </ol>
              <p class="muted">New to presets? Speed up design with our <a class="highlight-link" href="<?php echo home_url('//blog/how-to-use-presets-in-alightmotion/'); ?>">Preset Guide</a> and learn sharing workflows in the <a class="highlight-link" href="<?php echo home_url('//blog/how-to-use-qr-codes-in-alightmotion/'); ?>">QR Codes guide</a>.</p>

              <h2 id="style">How to Style Your Text Like a Pro</h2>
              <h3>1) Choose a clean, on‑brand font</h3>
              <ul class="about-feature-list">
                <li><span>Pick from built‑in fonts or install customs (<a href="https://www.dafont.com/" target="_blank" rel="nofollow noopener" class="external-link">DaFont</a>, <a href="https://www.fontspace.com/" target="_blank" rel="nofollow noopener" class="external-link">FontSpace</a>).</span></li>
                <li><span>Use one bold display font for titles and a simple font for body/captions.</span></li>
              </ul>

              <h3>2) Color for readability</h3>
              <ul class="about-feature-list">
                <li><span>White text + black stroke is highly legible on busy footage.</span></li>
                <li><span>Ensure strong contrast; avoid red on blue or yellow on white.</span></li>
              </ul>

              <h3>3) Size, spacing, alignment</h3>
              <ul class="about-feature-list">
                <li><span>Make titles large; keep captions compact.</span></li>
                <li><span>Adjust tracking (letter spacing) and line height for clean blocks.</span></li>
                <li><span>Center alignment works best for headlines.</span></li>
              </ul>

              <h3>4) Effects for clarity</h3>
              <ul class="about-feature-list">
                <li><span><strong>Stroke</strong> and <strong>shadow</strong> add separation from the background.</span></li>
                <li><span>Use a subtle <strong>background box</strong> behind small text when footage is bright.</span></li>
              </ul>

              <h2 id="animate">Make Your Text Move — Simple Animation</h2>
              <ol class="about-feature-list" style="list-style: decimal; padding-left: 1.25rem;">
                <li><span><strong>Open Animation</strong>: select the text layer → enable keyframes.</span></li>
                <li><span><strong>Fade‑in</strong>: at 0s set Opacity to 0%; at 1s set to 100%.</span></li>
                <li><span><strong>Slide/Grow/Spin</strong>: animate Position, Scale, or Rotation between two keyframes.</span></li>
                <li><span><strong>Timing curves</strong>: use ease‑in/out for natural motion.</span></li>
              </ol>
              <p>Add extra mood with <strong>Glow</strong> or <strong>Blur</strong> under Effects. For more animation ideas, see <a class="highlight-link" href="<?php echo home_url('//blog/10-pro-tips-alightmotion/'); ?>">10 Pro Tips</a>.</p>

              <h2 id="tips">Top Tips for Great‑Looking Text</h2>
              <ul class="about-feature-list">
                <li><span><strong>High contrast</strong> is king; check legibility on phone screens.</span></li>
                <li><span><strong>Keep it short</strong>: 3–6 words per screen reads best.</span></li>
                <li><span><strong>Limit to two fonts</strong> to avoid visual clutter.</span></li>
                <li><span><strong>Preview on device</strong> before exporting; adjust size if needed.</span></li>
                <li><span><strong>Save as preset</strong>: long‑press the styled layer → <em>Save as Preset</em> for reuse.</span></li>
              </ul>

              <div class="cta-box" style="margin-top:1.25rem;">
                <h4>Build a re‑usable title toolkit</h4>
                <p>Download the latest build, create text styles, and save them as presets. Learn sharing via our <a class="highlight-link" href="<?php echo home_url('//blog/how-to-use-qr-codes-in-alightmotion/'); ?>">Presets &amp; QR Codes Guide</a>.</p>
                                  <a class="btn btn-primary" href="<?php echo home_url('//#download/'); ?>">Download AlightMotion Premium</a>
                  <a class="btn btn-secondary" href="<?php echo home_url('//#features/'); ?>" style="margin-left:8px;">Explore Features</a>
              </div>

              <h2 id="faq">Frequently Asked Questions (FAQ)</h2>
              <div class="faq-list">
                <div class="faq-item">
                  <button class="faq-question"><span>Can I use custom fonts in AlightMotion?</span><svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>
                  <div class="faq-answer"><p>Yes — install <code>.ttf</code> or <code>.otf</code> fonts from reputable sources like <a href="https://www.dafont.com/" target="_blank" rel="nofollow noopener" class="external-link">DaFont</a> or <a href="https://www.fontspace.com/" target="_blank" rel="nofollow noopener" class="external-link">FontSpace</a>.</p></div>
                </div>
                <div class="faq-item">
                  <button class="faq-question"><span>Why is my text blurry on export?</span><svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>
                  <div class="faq-answer"><p>Match project resolution to your platform (e.g., 1080×1920 for Reels/Shorts), avoid over‑scaling small text, and export at high quality.</p></div>
                </div>
                <div class="faq-item">
                  <button class="faq-question"><span>How do I time when text appears?</span><svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>
                  <div class="faq-answer"><p>Drag the text layer along the timeline to the start time you want, then animate opacity/position for entrances.</p></div>
                </div>
                <div class="faq-item">
                  <button class="faq-question"><span>Can I animate text along a path?</span><svg class="faq-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 9L12 15L18 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></button>
                  <div class="faq-answer"><p>Yes — use the Path feature for arcs or circles. It’s great for logos and stylish intros.</p></div>
                </div>
              </div>

              <p class="muted">Keep learning: <a class="highlight-link" href="<?php echo home_url('//blog/10-pro-tips-alightmotion/'); ?>">10 Pro Tips for AlightMotion</a> • <a class="highlight-link" href="<?php echo home_url('//blog/how-to-import-xml-in-alightmotion/'); ?>">Import XML Projects</a> • <a class="highlight-link" href="<?php echo home_url('//blog/how-to-use-presets-in-alightmotion/'); ?>">Use Presets</a>. Official app info: <a href="https://www.alightmotion.com/" target="_blank" rel="nofollow noopener" class="external-link">alightmotion.com</a>.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

  
  <script src="script.js"></script>



</div>

<?php get_footer(); ?>