<?php
/**
 * Template for Privacy Policy - AlightMotion Premium APK | Data Protection
 * Generated from: alight-motion-website/alight-motion-website/privacy-policy.html
 */

get_header(); ?>

<div class="page-content">
    
    <!-- Header -->
    

    <!-- Main Content -->
    <main>
        <!-- Hero Section -->
        <section class="hero" style="padding: 120px 0 80px;">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h1>Privacy Policy</h1>
                    <p>Last updated: August 11, 2024</p>
                </div>
            </div>
        </section>

        <!-- Privacy Policy Content -->
        <section class="about" style="padding: 40px 0 80px;">
            <div class="container">
                <div class="about-card">
                    <div class="about-content">
                        <div class="about-description">
                            <h3>Introduction</h3>
                            <p>This Privacy Policy describes how AlightMotion Premium ("we," "us," or "our") collects, uses, and protects your information when you use our mobile application and related services.</p>
                            
                            <h3>Information We Collect</h3>
                            <p>We may collect the following types of information:</p>
                            <ul class="about-feature-list">
                                <li><span>Device information (device model, operating system version)</span></li>
                                <li><span>App usage statistics and crash reports</span></li>
                                <li><span>Analytics data to improve app performance</span></li>
                                <li><span>User preferences and settings</span></li>
                            </ul>
                            
                            <h3>How We Use Your Information</h3>
                            <p>We use the collected information to:</p>
                            <ul class="about-feature-list">
                                <li><span>Provide and maintain our services</span></li>
                                <li><span>Improve app functionality and user experience</span></li>
                                <li><span>Analyze app performance and fix issues</span></li>
                                <li><span>Send important updates and notifications</span></li>
                            </ul>
                            
                            <h3>Data Security</h3>
                            <p>We implement appropriate security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.</p>
                            
                            <h3>Third-Party Services</h3>
                            <p>Our app may use third-party services for analytics and crash reporting. These services have their own privacy policies, and we encourage you to review them.</p>
                            
                            <h3>Data Retention</h3>
                            <p>We retain your information only for as long as necessary to provide our services and comply with legal obligations.</p>
                            
                            <h3>Your Rights</h3>
                            <p>You have the right to:</p>
                            <ul class="about-feature-list">
                                <li><span>Access your personal information</span></li>
                                <li><span>Request correction of inaccurate data</span></li>
                                <li><span>Request deletion of your data</span></li>
                                <li><span>Opt-out of certain data collection</span></li>
                            </ul>
                            
                            <h3>Children's Privacy</h3>
                            <p>Our app is not intended for children under 13. We do not knowingly collect personal information from children under 13.</p>
                            
                            <h3>Changes to This Policy</h3>
                            <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
                            
                            <h3>Contact Us</h3>
                            <p>If you have any questions about this Privacy Policy, please contact us through our social media channels or email.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    

    <!-- JavaScript -->
    <script src="script.js"></script>



</div>

<?php get_footer(); ?>