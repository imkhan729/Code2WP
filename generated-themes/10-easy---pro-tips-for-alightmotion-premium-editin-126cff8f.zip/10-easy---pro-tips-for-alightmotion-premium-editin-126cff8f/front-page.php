<?php get_header(); ?>


    <p>Redirecting to <a href="<?php echo home_url('//blog/'); ?>">Blog</a>...</p>




<?php get_footer(); ?>