<?php get_header(); ?>

<div class="search-results">
    <header class="page-header">
        <h1 class="page-title">
            <?php printf('Search Results for: %s', get_search_query()); ?>
        </h1>
    </header>
    
    <div class="search-content">
        <?php if (have_posts()) : ?>
            <div class="search-results-list">
                <?php while (have_posts()) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <h2 class="entry-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        
                        <div class="entry-summary">
                            <?php the_excerpt(); ?>
                        </div>
                        
                        <div class="entry-meta">
                            <span class="post-type"><?php echo get_post_type(); ?></span>
                            <time class="entry-date"><?php echo get_the_date(); ?></time>
                        </div>
                    </article>
                <?php endwhile; ?>
                
                <div class="pagination">
                    <?php the_posts_pagination(); ?>
                </div>
            </div>
        <?php else : ?>
            <div class="no-results">
                <p>Sorry, but nothing matched your search terms. Please try again with some different keywords.</p>
                <?php get_search_form(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>