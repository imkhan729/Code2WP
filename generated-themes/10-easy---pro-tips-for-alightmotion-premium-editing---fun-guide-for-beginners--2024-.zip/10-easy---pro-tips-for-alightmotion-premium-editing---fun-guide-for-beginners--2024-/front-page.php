<?php get_header(); ?>


    <p>Redirecting to <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>...</p>




<?php get_footer(); ?>