<?php
/**
 * Template for Privacy Policy - Alight Motion Mod APKToggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: privacy-policy.html
 */

get_header(); ?>

<div class="page-content">
    
<div id="wrapper" class="site wp-site-blocks">
			<a class="skip-link screen-reader-text scroll-ignore" href="#main">Skip to content</a>
		<!-- #masthead -->

	<div id="inner-wrap" class="wrap hfeed kt-clear">
		<div id="primary" class="content-area">
	<div class="content-container site-container">
		<main id="main" class="site-main" role="main">
						<div class="content-wrap">
				<article id="post-56" class="entry content-bg single-entry post-56 page type-page status-publish hentry">
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id56_d42215-f3 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column56_fe3017-64"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading56_db198c-5f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_db198c-5f">Privacy Policy</h1>



<p class="kt-adv-heading56_095a6d-ee wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_095a6d-ee">At alightmotionsapp.com, accessible from <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by alightmotionsapp.com and how we use it.</p>



<p class="kt-adv-heading56_402c9b-6d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_402c9b-6d">If you have additional questions or require more information about our Privacy Policy, do not hesitate to <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>.</p>



<p class="kt-adv-heading56_030e19-a1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_030e19-a1">This Privacy Policy applies only to our online activities and is valid for visitors to our website regarding the information that they share and/or collect on alightmotionsapp.com. It is not applicable to any information collected offline or via channels other than this website.</p>



<h2 class="kt-adv-heading56_ae1166-b0 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_ae1166-b0">Consent</h2>



<p class="kt-adv-heading56_4afae0-34 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_4afae0-34">By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.</p>



<h2 class="kt-adv-heading56_60136b-18 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_60136b-18">Information we collect</h2>



<p class="kt-adv-heading56_3b29ae-b1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_3b29ae-b1">When you provide personal information, such as your name and address, it will be made evident to you why this information is being collected and how it will be used. ⁤</p>



<p class="kt-adv-heading56_7ba605-38 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_7ba605-38">⁤When you <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>, there is a good chance that we will acquire additional information about you such as your name, email address, phone number, and the messages and their attachments, as well as any other information that you may wish to share. ⁤</p>



<p class="kt-adv-heading56_c19360-7f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_c19360-7f">⁤When you sign up for an Account, we may require you to give your contact details, which can include: name, company name, address, e-mail address, and telephone number</p>



<h2 class="kt-adv-heading56_0d5fd9-4c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_0d5fd9-4c"><strong>How we use your information</strong></h2>



<ul class="wp-block-list">
<li>Manage, Provide, and maintain our site.</li>



<li>Keep improving, personalizing, and expanding our website.</li>



<li>Learning and bringing to light how you use our website.</li>



<li>Develop new products, services, features and functions.</li>



<li>I will talk with you, either directly or through a partner, which may include customer service updates and other website-related information. This may also be used for marketing and promotional purposes.</li>



<li>Send you emails.</li>



<li>Find and prevent fraud.</li>
</ul>



<h2 class="kt-adv-heading56_5d9144-dc wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_5d9144-dc">Log Files</h2>



<p class="kt-adv-heading56_e8e899-2e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_e8e899-2e">alightmotionsapp.com follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and are a part of hosting services’ analytics. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is to analyze trends, administer the site, track users’ movement on the website, and gather demographic information.</p>



<h2 class="kt-adv-heading56_26fbc7-2f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_26fbc7-2f">Google DoubleClick DART Cookie</h2>



<p class="kt-adv-heading56_ebdfa1-15 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_ebdfa1-15">Google is one of the third-party vendors on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL –&nbsp;<a href="https://policies.google.com/technologies/ads" rel="noopener">https://policies.google.com/technologies/ads</a></p>



<h2 class="kt-adv-heading56_547b79-7a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_547b79-7a">A<strong>dvertising Partners</strong> Privacy Policies</h2>



<p class="kt-adv-heading56_407f72-cf wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_407f72-cf">You may consult this list to find the Privacy Policy for each of the advertising partners of alightmotionsapp.com.</p>



<p class="kt-adv-heading56_446d95-1c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_446d95-1c">Third-party ad servers or ad networks use technologies like cookies, JavaScript, or Web Beacons in their respective advertisements and links that appear on alightmotionsapp.com. These are sent directly to users’ browsers, and they automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>



<p class="kt-adv-heading56_285cea-6b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_285cea-6b">Note that alightmotionsapp.com has no access to or control over these cookies that third-party advertisers use.</p>



<h2 class="kt-adv-heading56_4ff1a5-d3 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_4ff1a5-d3">Third Party Privacy Policies</h2>



<p class="kt-adv-heading56_d0fa62-19 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_d0fa62-19">alightmotionsapp.com’s privacy policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt out of certain options.</p>



<p class="kt-adv-heading56_125d4b-7c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_125d4b-7c">You can choose to disable cookies through your individual browser options. More detailed information about cookie management with specific web browsers can be found on their respective websites. What Are Cookies?</p>



<h2 class="kt-adv-heading56_69561c-ff wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_69561c-ff">Children’s Information</h2>



<p class="kt-adv-heading56_9012c0-67 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_9012c0-67">Another part of our priority is protecting children while using the Internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.</p>



<p class="kt-adv-heading56_7f55b3-4e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_7f55b3-4e">alightmotionsapp.com does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>



<h2 class="kt-adv-heading56_f01fa0-f5 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_f01fa0-f5">Online Privacy Policy Only</h2>



<p class="kt-adv-heading56_d88520-68 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_d88520-68">This Privacy Policy applies only to our online activities and is valid for visitors to our website with regard to the information that they share and/or collect in alightmotionsapp.com. This policy is not applicable to any information collected offline or via channels other than this website.</p>



<h2 class="kt-adv-heading56_69e2dd-e3 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_69e2dd-e3">Contact Us</h2>



<p>If you have any questions about this Privacy Policy, the practices of this Site, or your dealings with this Site, please <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>.</p>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>
</article><!-- #post-56 -->

			</div>
					</main><!-- #main -->
			</div>
</div><!-- #primary -->
	</div><!-- #inner-wrap -->
	<!-- #colophon -->

</div><!-- #wrapper -->

			<script type="95014e79e3f67d219f9f56c8-text/javascript">document.documentElement.style.setProperty('--scrollbar-offset', window.innerWidth - document.documentElement.clientWidth + 'px' );</script>
			<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/kadence\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<a id="kt-scroll-up" tabindex="-1" aria-hidden="true" aria-label="Scroll to top" href="#wrapper" class="kadence-scroll-to-top scroll-up-wrap scroll-ignore scroll-up-side-right scroll-up-style-filled vs-lg-true vs-md-true vs-sm-false"><span class="kadence-svg-iconset"><svg aria-hidden="true" class="kadence-svg-icon kadence-arrow-up2-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"><title>Scroll to top</title><path d="M25.172 15.172c0 0.531-0.219 1.031-0.578 1.406l-1.172 1.172c-0.375 0.375-0.891 0.594-1.422 0.594s-1.047-0.219-1.406-0.594l-4.594-4.578v11c0 1.125-0.938 1.828-2 1.828h-2c-1.062 0-2-0.703-2-1.828v-11l-4.594 4.578c-0.359 0.375-0.875 0.594-1.406 0.594s-1.047-0.219-1.406-0.594l-1.172-1.172c-0.375-0.375-0.594-0.875-0.594-1.406s0.219-1.047 0.594-1.422l10.172-10.172c0.359-0.375 0.875-0.578 1.406-0.578s1.047 0.203 1.422 0.578l10.172 10.172c0.359 0.375 0.578 0.891 0.578 1.422z"></path>
				</svg></span></a><button id="kt-scroll-up-reader" href="#wrapper" aria-label="Scroll to top" class="kadence-scroll-to-top scroll-up-wrap scroll-ignore scroll-up-side-right scroll-up-style-filled vs-lg-true vs-md-true vs-sm-false"><span class="kadence-svg-iconset"><svg aria-hidden="true" class="kadence-svg-icon kadence-arrow-up2-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"><title>Scroll to top</title><path d="M25.172 15.172c0 0.531-0.219 1.031-0.578 1.406l-1.172 1.172c-0.375 0.375-0.891 0.594-1.422 0.594s-1.047-0.219-1.406-0.594l-4.594-4.578v11c0 1.125-0.938 1.828-2 1.828h-2c-1.062 0-2-0.703-2-1.828v-11l-4.594 4.578c-0.359 0.375-0.875 0.594-1.406 0.594s-1.047-0.219-1.406-0.594l-1.172-1.172c-0.375-0.375-0.594-0.875-0.594-1.406s0.219-1.047 0.594-1.422l10.172-10.172c0.359-0.375 0.875-0.578 1.406-0.578s1.047 0.203 1.422 0.578l10.172 10.172c0.359 0.375 0.578 0.891 0.578 1.422z"></path>
				</svg></span></button>	<div id="mobile-drawer" class="popup-drawer popup-drawer-layout-sidepanel popup-drawer-animation-fade popup-drawer-side-right" data-drawer-target-string="#mobile-drawer">
		<div class="drawer-overlay" data-drawer-target-string="#mobile-drawer"></div>
		<div class="drawer-inner">
						<div class="drawer-header">
				<button class="menu-toggle-close drawer-toggle" aria-label="Close menu" data-toggle-target="#mobile-drawer" data-toggle-body-class="showing-popup-drawer-from-right" aria-expanded="false" data-set-focus=".menu-toggle-open">
					<span class="toggle-close-bar"></span>
					<span class="toggle-close-bar"></span>
				</button>
			</div>
			<div class="drawer-content mobile-drawer-content content-align-left content-valign-top">
								<div class="site-header-item site-header-focus-item site-header-item-mobile-navigation mobile-navigation-layout-stretch-false" data-section="kadence_customizer_mobile_navigation">
		<!-- #site-navigation -->
	</div><!-- data-section="mobile_navigation" -->
							</div>
		</div>
	</div>
	<script src="https://alightmotionsapp.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js" defer="" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script src="https://alightmotionsapp.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js" defer="" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script id="wp-i18n-js-after" type="95014e79e3f67d219f9f56c8-text/javascript">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="https://alightmotionsapp.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.0.2" id="swv-js" defer="" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script id="contact-form-7-js-before" type="95014e79e3f67d219f9f56c8-text/javascript">
var wpcf7 = {
    "api": {
        "root": "https:\/\/alightmotionsapp.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
</script>
<script src="https://alightmotionsapp.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.0.2" id="contact-form-7-js" defer="" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script id="rocket-browser-checker-js-after" type="95014e79e3f67d219f9f56c8-text/javascript">
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
</script>
<script id="rocket-preload-links-js-extra" type="95014e79e3f67d219f9f56c8-text/javascript">
var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index.php\/)?(.*)wp-json(\/.*|$)|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https:\/\/alightmotionsapp.com","onHoverDelay":"100","rateThrottle":"3"};
</script>
<script id="rocket-preload-links-js-after" type="95014e79e3f67d219f9f56c8-text/javascript">
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
</script>
<script id="kadence-navigation-js-extra" type="95014e79e3f67d219f9f56c8-text/javascript">
var kadenceConfig = {"screenReader":{"expand":"Child menu","expandOf":"Child menu of","collapse":"Child menu","collapseOf":"Child menu of"},"breakPoints":{"desktop":"1024","tablet":768},"scrollOffset":"0"};
</script>
<script src="https://alightmotionsapp.com/wp-content/themes/kadence/assets/js/navigation.min.js?ver=1.2.4" id="kadence-navigation-js" async="" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script async="" data-no-optimize="1" src="https://alightmotionsapp.com/wp-content/plugins/perfmatters/vendor/instant-page/pminstantpage.min.js?ver=2.2.6" id="perfmatters-instant-page-js" type="95014e79e3f67d219f9f56c8-text/javascript"></script>
<script id="perfmatters-delayed-scripts-js" type="95014e79e3f67d219f9f56c8-text/javascript">const pmDelayClick=false;const pmDelayTimer=setTimeout(pmTriggerDOMListener,10*1000);const pmUserInteractions=["keydown","mousedown","mousemove","wheel","touchmove","touchstart","touchend"],pmDelayedScripts={normal:[],defer:[],async:[]},jQueriesArray=[],pmInterceptedClicks=[];var pmDOMLoaded=!1,pmClickTarget="";function pmTriggerDOMListener(){"undefined"!=typeof pmDelayTimer&&clearTimeout(pmDelayTimer),pmUserInteractions.forEach(function(e){window.removeEventListener(e,pmTriggerDOMListener,{passive:!0})}),document.removeEventListener("visibilitychange",pmTriggerDOMListener),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",pmTriggerDelayedScripts):pmTriggerDelayedScripts()}async function pmTriggerDelayedScripts(){pmDelayEventListeners(),pmDelayJQueryReady(),pmProcessDocumentWrite(),pmSortDelayedScripts(),pmPreloadDelayedScripts(),await pmLoadDelayedScripts(pmDelayedScripts.normal),await pmLoadDelayedScripts(pmDelayedScripts.defer),await pmLoadDelayedScripts(pmDelayedScripts.async),await pmTriggerEventListeners(),document.querySelectorAll("link[data-pmdelayedstyle]").forEach(function(e){e.setAttribute("href",e.getAttribute("data-pmdelayedstyle"))}),window.dispatchEvent(new Event("perfmatters-allScriptsLoaded")),pmReplayClicks()}function pmDelayEventListeners(){let e={};function t(t,r){function n(r){return e[t].delayedEvents.indexOf(r)>=0?"perfmatters-"+r:r}e[t]||(e[t]={originalFunctions:{add:t.addEventListener,remove:t.removeEventListener},delayedEvents:[]},t.addEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.add.apply(t,arguments)},t.removeEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.remove.apply(t,arguments)}),e[t].delayedEvents.push(r)}function r(e,t){let r=e[t];Object.defineProperty(e,t,{get:r||function(){},set:function(r){e["perfmatters"+t]=r}})}t(document,"DOMContentLoaded"),t(window,"DOMContentLoaded"),t(window,"load"),t(window,"pageshow"),t(document,"readystatechange"),r(document,"onreadystatechange"),r(window,"onload"),r(window,"onpageshow")}function pmDelayJQueryReady(){let e=window.jQuery;Object.defineProperty(window,"jQuery",{get:()=>e,set(t){if(t&&t.fn&&!jQueriesArray.includes(t)){t.fn.ready=t.fn.init.prototype.ready=function(e){pmDOMLoaded?e.bind(document)(t):document.addEventListener("perfmatters-DOMContentLoaded",function(){e.bind(document)(t)})};let r=t.fn.on;t.fn.on=t.fn.init.prototype.on=function(){if(this[0]===window){function e(e){return e=(e=(e=e.split(" ")).map(function(e){return"load"===e||0===e.indexOf("load.")?"perfmatters-jquery-load":e})).join(" ")}"string"==typeof arguments[0]||arguments[0]instanceof String?arguments[0]=e(arguments[0]):"object"==typeof arguments[0]&&Object.keys(arguments[0]).forEach(function(t){delete Object.assign(arguments[0],{[e(t)]:arguments[0][t]})[t]})}return r.apply(this,arguments),this},jQueriesArray.push(t)}e=t}})}function pmProcessDocumentWrite(){let e=new Map;document.write=document.writeln=function(t){var r=document.currentScript,n=document.createRange();let a=e.get(r);void 0===a&&(a=r.nextSibling,e.set(r,a));var i=document.createDocumentFragment();n.setStart(i,0),i.appendChild(n.createContextualFragment(t)),r.parentElement.insertBefore(i,a)}}function pmSortDelayedScripts(){document.querySelectorAll("script[type=pmdelayedscript]").forEach(function(e){e.hasAttribute("src")?e.hasAttribute("defer")&&!1!==e.defer?pmDelayedScripts.defer.push(e):e.hasAttribute("async")&&!1!==e.async?pmDelayedScripts.async.push(e):pmDelayedScripts.normal.push(e):pmDelayedScripts.normal.push(e)})}function pmPreloadDelayedScripts(){var e=document.createDocumentFragment();[...pmDelayedScripts.normal,...pmDelayedScripts.defer,...pmDelayedScripts.async].forEach(function(t){var r=t.getAttribute("src");if(r){var n=document.createElement("link");n.href=r,n.rel="preload",n.as="script",e.appendChild(n)}}),document.head.appendChild(e)}async function pmLoadDelayedScripts(e){var t=e.shift();return t?(await pmReplaceScript(t),pmLoadDelayedScripts(e)):Promise.resolve()}async function pmReplaceScript(e){return await pmNextFrame(),new Promise(function(t){let r=document.createElement("script");[...e.attributes].forEach(function(e){let t=e.nodeName;"type"!==t&&("data-type"===t&&(t="type"),r.setAttribute(t,e.nodeValue))}),e.hasAttribute("src")?(r.addEventListener("load",t),r.addEventListener("error",t)):(r.text=e.text,t()),e.parentNode.replaceChild(r,e)})}async function pmTriggerEventListeners(){pmDOMLoaded=!0,await pmNextFrame(),document.dispatchEvent(new Event("perfmatters-DOMContentLoaded")),await pmNextFrame(),window.dispatchEvent(new Event("perfmatters-DOMContentLoaded")),await pmNextFrame(),document.dispatchEvent(new Event("perfmatters-readystatechange")),await pmNextFrame(),document.perfmattersonreadystatechange&&document.perfmattersonreadystatechange(),await pmNextFrame(),window.dispatchEvent(new Event("perfmatters-load")),await pmNextFrame(),window.perfmattersonload&&window.perfmattersonload(),await pmNextFrame(),jQueriesArray.forEach(function(e){e(window).trigger("perfmatters-jquery-load")});let e=new Event("perfmatters-pageshow");e.persisted=window.pmPersisted,window.dispatchEvent(e),await pmNextFrame(),window.perfmattersonpageshow&&window.perfmattersonpageshow({persisted:window.pmPersisted})}async function pmNextFrame(){return new Promise(function(e){requestAnimationFrame(e)})}function pmClickHandler(e){e.target.removeEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"pm-onclick","onclick"),pmInterceptedClicks.push(e),e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()}function pmReplayClicks(){window.removeEventListener("touchstart",pmTouchStartHandler,{passive:!0}),window.removeEventListener("mousedown",pmTouchStartHandler),pmInterceptedClicks.forEach(e=>{e.target.outerHTML===pmClickTarget&&e.target.dispatchEvent(new MouseEvent("click",{view:e.view,bubbles:!0,cancelable:!0}))})}function pmTouchStartHandler(e){"HTML"!==e.target.tagName&&(pmClickTarget||(pmClickTarget=e.target.outerHTML),window.addEventListener("touchend",pmTouchEndHandler),window.addEventListener("mouseup",pmTouchEndHandler),window.addEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.addEventListener("mousemove",pmTouchMoveHandler),e.target.addEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"onclick","pm-onclick"))}function pmTouchMoveHandler(e){window.removeEventListener("touchend",pmTouchEndHandler),window.removeEventListener("mouseup",pmTouchEndHandler),window.removeEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",pmTouchMoveHandler),e.target.removeEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"pm-onclick","onclick")}function pmTouchEndHandler(e){window.removeEventListener("touchend",pmTouchEndHandler),window.removeEventListener("mouseup",pmTouchEndHandler),window.removeEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",pmTouchMoveHandler)}function pmRenameDOMAttribute(e,t,r){e.hasAttribute&&e.hasAttribute(t)&&(event.target.setAttribute(r,event.target.getAttribute(t)),event.target.removeAttribute(t))}window.addEventListener("pageshow",e=>{window.pmPersisted=e.persisted}),pmUserInteractions.forEach(function(e){window.addEventListener(e,pmTriggerDOMListener,{passive:!0})}),pmDelayClick&&(window.addEventListener("touchstart",pmTouchStartHandler,{passive:!0}),window.addEventListener("mousedown",pmTouchStartHandler)),document.addEventListener("visibilitychange",pmTriggerDOMListener);</script><script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="95014e79e3f67d219f9f56c8-|49" defer=""></script>





</div>

<?php get_footer(); ?>