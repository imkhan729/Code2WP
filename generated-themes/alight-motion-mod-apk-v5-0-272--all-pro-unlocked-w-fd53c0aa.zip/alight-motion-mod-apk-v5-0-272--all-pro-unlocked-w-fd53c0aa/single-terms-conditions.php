<?php
/**
 * Single post template for Terms & Conditions - Alight Motion Mod APKToggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: terms-conditions.html
 */

get_header(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-meta">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
            <span class="author"><?php the_author(); ?></span>
        </div>
    </header>

    <div class="entry-content">
        
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id58_33416f-34 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column58_228209-df"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading58_ee8780-42 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_ee8780-42">Terms &amp; Conditions</h1>



<p class="kt-adv-heading58_4ea39e-50 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_4ea39e-50">Welcome to alightmotionsapp.com</p>



<p class="kt-adv-heading58_ebc7f8-96 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_ebc7f8-96">These terms and conditions outline the rules and regulations for using the website alightmotionsapp.com, located at <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a>.</p>



<p class="kt-adv-heading58_c96ae6-99 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_c96ae6-99">By accessing this website we assume you accept these terms and conditions. Do not continue to use alightmotionsapp.com if you do not agree to take all of the terms and conditions stated on this page.</p>



<p class="kt-adv-heading58_f2b9b1-79 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_f2b9b1-79">The following terminology applies to these Terms and Conditions, Privacy Statement and Disclaimer Notice and all Agreements: “Client”, “You” and “Your” refers to you, the person log on this website and compliant to the Company’s terms and conditions. “The Company”, “Ourselves”, “We”, “Our”, and “Us” refer to our Company. “Party”, “Parties”, or “Us”, refers to both the Client and ourselves. All terms refer to the offer, acceptance and consideration of payment necessary to undertake the process of our assistance to the Client in the most appropriate manner for the express purpose of meeting the Client’s needs in respect of the provision of the Company’s stated services, in accordance with and subject to, prevailing law of Netherlands. Any use of the above terminology or other words in the singular, plural, capitalization and/or he/she or they are considered interchangeable and, therefore, refer to the same.</p>



<h2 class="kt-adv-heading58_7c2544-98 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_7c2544-98">Cookies</h2>



<p class="kt-adv-heading58_e2396e-f4 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_e2396e-f4">We employ the use of cookies. By accessing alightmotionsapp.com, you agree to use cookies in agreement with the alightmotionsapp.com <a href="https://alightmotions.webakesweb.com/privacy-policy/" rel="noopener">Privacy Policy</a>.</p>



<p class="kt-adv-heading58_0869eb-5d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_0869eb-5d">Most interactive websites use cookies to let us retrieve the user’s details for each visit. Our website uses cookies to enable the functionality of certain areas and make it easier for people visiting our website. Some of our affiliate/advertising partners may also use cookies.</p>



<h2 class="kt-adv-heading58_db9072-6d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_db9072-6d"><strong>License</strong></h2>



<p class="kt-adv-heading58_9c715d-5c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_9c715d-5c">Unless otherwise stated, alightmotionsapp.com and/or its licensors own the intellectual property rights for all material on alightmotionsapp.com. All intellectual property rights are reserved. You may access this from alightmotionsapp.com for your own personal use, subject to restrictions set in these terms and conditions.</p>



<p class="kt-adv-heading58_04ac64-fa wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_04ac64-fa">You must not:</p>



<ul class="wp-block-list">
<li>Republish material from alightmotionsapp.com</li>



<li>Sell, rent or sub-license material from alightmotionsapp.com</li>



<li>Reproduce, duplicate or copy material from alightmotionsapp.com</li>



<li>Redistribute content from alightmotionsapp.com</li>
</ul>



<p class="kt-adv-heading58_1fbca6-3f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_1fbca6-3f">This Agreement shall begin on the date hereof.</p>



<p class="has--font-size">Parts of this website offer an opportunity for users to post and exchange opinions and information in certain areas of the website. alightmotionsapp.com does not filter, edit, publish or review Comments before their presence on the website. Comments do not reflect the views and opinions of alightmotionsapp.com, its agents and/or affiliates. Comments reflect the views and opinions of the person who posts their views and opinions. To the extent permitted by applicable laws, alightmotionsapp.com shall not be liable for the Comments or any liability, damages or expenses caused and/or suffered as a result of any use of and/or posting of and/or appearance of the Comments on this website.</p>



<p class="kt-adv-heading58_837d61-e5 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_837d61-e5">alightmotionsapp.com reserves the right to monitor all Comments and to remove any Comments that are considered inappropriate, offensive, or in breach of these Terms and Conditions.</p>



<p>You warrant and represent that:</p>



<ul class="wp-block-list">
<li>You are entitled to post the Comments on our website and have all necessary licenses and consents to do so;</li>



<li>The Comments do not invade any intellectual property right, including without limitation copyright, patent or trademark of any third party;</li>



<li>The Comments do not contain defamatory, libellous, offensive, indecent or otherwise unlawful material that is an invasion of privacy.</li>



<li>The Comments will not be used to solicit or promote business or custom or present commercial activities or unlawful activity.</li>
</ul>



<p>You hereby grant alightmotionsapp.com a non-exclusive license to use, reproduce, edit and authorize others to use, reproduce and edit any of your Comments in any and all forms, formats or media.</p>



<h2 class="kt-adv-heading58_668c60-80 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_668c60-80"><strong>Hyperlinking to our Content</strong></h2>



<p>The following organizations may link to our Website without prior written approval:</p>



<ul class="wp-block-list">
<li>Government agencies;</li>



<li>Search engines;</li>



<li>News organizations;</li>



<li>Online directory distributors may link to our Website in the same manner as they hyperlink to the Websites of other listed businesses and</li>



<li>System-wide Accredited Businesses except soliciting non-profit organizations, charity shopping malls, and charity fundraising groups, which may not hyperlink to our website.</li>
</ul>



<p>These organizations may link to our home page, publications, or other Website information so long as the link (a) is not deceptive; (b) does not falsely imply sponsorship, endorsement, or approval of the linking party and its products and/or services; and (c) fits within the context of the linking party’s site.</p>



<p>We may consider and approve other link requests from the following types of organizations:</p>



<ul class="wp-block-list">
<li>commonly-known consumer and/or business information sources;</li>



<li>dot.com community sites;</li>



<li>associations or other groups representing charities;</li>



<li>online directory distributors;</li>



<li>internet portals;</li>



<li>accounting, law and consulting firms; and</li>



<li>educational institutions and trade associations.</li>
</ul>



<p>We will approve link requests from these organizations if we decide that: (a) the link would not make us look unfavourably to ourselves or our accredited businesses; (b) the organization does not have any negative records with us; (c) the benefit to us from the visibility of the hyperlink compensates the absence of alightmotionsapp.com; and (d) the link is in the context of general resource information.</p>



<p>These organizations may link to our home page so long as the link (a) is not deceptive, (b) does not falsely imply sponsorship, endorsement, or approval of the linking party and its products or services, and (c) fits within the context of the linking party’s site.</p>



<p>If you are one of the organizations listed in paragraph 2 above and are interested in linking to our website, you must inform us by sending an e-mail to alightmotionsapp.com. Please include your name, your organization name, and contact information, the URL of your site, a list of any URLs from which you intend to link to our Website, and a list of the URLs on our site to which you would like to link. Wait 2-3 weeks for a response.</p>



<p>Approved organizations may hyperlink to our Website as follows:</p>



<ul class="wp-block-list">
<li>By use of our corporate name or</li>



<li>By use of the uniform resource locator being linked to or</li>



<li>By use of any other description of our Website being linked to that makes sense within the context and format of content on the linking party’s site.</li>
</ul>



<p>No use of the alightmotionsapp.com logo or other artwork will be allowed for linking absent a trademark license agreement.</p>



<h2 class="kt-adv-heading58_ec75a7-3f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_ec75a7-3f"><strong>iFrames</strong></h2>



<p>Without prior approval and written permission, you may not create frames around our web pages that alter in any way the visual presentation or appearance of our Website.</p>



<h2 class="wp-block-heading has--font-size"><strong>Content Liability</strong></h2>



<p>We shall not be held responsible for any content that appears on your Website. You agree to protect and defend us against all claims that arise on your Website. No link(s) should appear on any Website that may be interpreted as libellous, obscene, or criminal or that infringes, otherwise violates, or advocates the infringement or other violation of any third-party rights.</p>



<h2 class="wp-block-heading has--font-size"><strong>Reservation of Rights</strong></h2>



<p>We reserve the right to request that you remove all or any particular link to our Website. You approve of removing all links to our Website upon request immediately. We also reserve the right to amend these terms and conditions and its linking policy at any time. By continuously linking to our Website, you agree to be bound to and follow these linking terms and conditions.</p>



<h2 class="wp-block-heading has--font-size"><strong>Removal of links from our website</strong></h2>



<p>If you find any link on our Website that is offensive for any reason, you are free to contact and inform us at any moment. We will consider requests to remove links, but we are not obligated to do so or to respond to you directly.</p>



<p>We do not ensure that the information on this website is correct, we do not warrant its completeness or accuracy; nor do we promise to ensure that the website remains available or that the material on the website is kept up to date.</p>



<h2 class="kt-adv-heading58_e68447-fa wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading58_e68447-fa"><strong>Disclaimer</strong></h2>



<p>To the maximum extent permitted by applicable law, we exclude all representations, warranties and conditions relating to our website and the use of this website. Nothing in this disclaimer will:</p>



<ul class="wp-block-list">
<li>limit or exclude our or your liability for death or personal injury;</li>



<li>limit or exclude our or your liability for fraud or fraudulent misrepresentation;</li>



<li>limit any of our or your liabilities in any way that is not permitted under applicable law or</li>



<li>exclude any of our or your liabilities that may not be excluded under applicable law.</li>
</ul>



<p>The limitations and prohibitions of liability set in this Section and elsewhere in this disclaimer (a) are subject to the preceding paragraph and (b) govern all liabilities arising under the disclaimer, including liabilities arising in contract, in tort and for breach of statutory duty.</p>



<p>As long as the website and the information and services on the website are provided free of charge, we will not be liable for any loss or damage of any nature.</p>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>

        <?php the_content(); ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<p>Tags: ', ', ', '</p>'); ?>
        <?php the_category(); ?>
    </footer>
</article>

<?php get_footer(); ?>