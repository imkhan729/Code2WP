<?php
/**
 * Single post template for About usToggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: about-us.html
 */

get_header(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-meta">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
            <span class="author"><?php the_author(); ?></span>
        </div>
    </header>

    <div class="entry-content">
        
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id48_80da10-df alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column48_357c61-91"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading48_9698ff-9c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading48_9698ff-9c">About us</h1>



<p class="kt-adv-heading48_fd7d81-9c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading48_fd7d81-9c">We’re the team behind the site <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a>, and we developed the moded version of the <strong>Alight Motion App</strong>. The goal is to create an apk file to give users more features and accessibility so they can easily edit the videos and make them more attractive designs. We have the experience and skill to edit the software to make your alight motion journey more valuable.</p>



<p>The modded version of the <strong>Alight Motion APK</strong> file we developed, you can easily download the file from this site: <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a>. A complete guide is available for installing it on your <strong><a href="https://www.android.com/" rel="noopener"><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Android </mark></a></strong>device. also a deep explanation of how to download and install <strong><a href="https://alightmotionsapp.com/alight-motion-for-pc/">Alight Motion Pro APK for PC</a></strong> and <strong><a href="https://alightmotionsapp.com/alight-motion-for-ios/">Alight Motion for IOS</a></strong> platform</p>



<p>You can access all these fantastic features in mod files, which are not present in the standard version of the software. The <strong>Alight Motion Mod</strong> feature includes no watermarks, no ad support for all presets, the ability to import any fonts on your videos, and the ability to unlock all effects. These features enhance the editing process by allowing users to add a more personal touch, resulting in more striking videos and motion graphics.</p>



<h2 class="kt-adv-heading48_216ba3-1f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading48_216ba3-1f">What’s on Our Site?</h2>



<ul class="wp-block-list">
<li>Alight Motion Overview</li>



<li>Complete Guide and Images Explanation</li>



<li>User Reviews</li>



<li>Free and Easy to download mod version</li>



<li>Feature listed</li>



<li><a href="https://alightmotionsapp.com/alight-motion-mod-apk-download/">All versions are available</a></li>
</ul>



<h2 class="kt-adv-heading48_667228-0a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading48_667228-0a">Why Choose Us</h2>



<ul class="wp-block-list">
<li>We are constantly working to improve our services and offerings to serve you better.</li>



<li>&nbsp;Stay updated on the latest news, innovations, lighting, motion, and video editing developments.</li>



<li>&nbsp;Provide a solution you might encounter when using <strong>Alight Motion Pro</strong>.</li>



<li>&nbsp;Unlock premium features to enhance your editing experience.</li>



<li>&nbsp;All versions are available.</li>
</ul>



<p>Feel free to reach out to us for any suggestions, feedback, or inquiries through our <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact form</a></p>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>

        <?php the_content(); ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<p>Tags: ', ', ', '</p>'); ?>
        <?php the_category(); ?>
    </footer>
</article>

<?php get_footer(); ?>