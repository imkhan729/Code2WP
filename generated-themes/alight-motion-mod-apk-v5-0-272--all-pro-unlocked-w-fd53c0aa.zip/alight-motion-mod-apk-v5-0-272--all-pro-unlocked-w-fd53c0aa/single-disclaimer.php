<?php
/**
 * Single post template for Disclaimer - Alight Motion Mod APKToggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: disclaimer.html
 */

get_header(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-meta">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
            <span class="author"><?php the_author(); ?></span>
        </div>
    </header>

    <div class="entry-content">
        
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id54_1b5cb8-26 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column54_db339f-ee"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading54_3809a1-ba wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_3809a1-ba">Disclaimer</h1>



<p class="kt-adv-heading54_699f94-e9 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_699f94-e9">If you require any more information or have any questions about our site’s disclaimer, please feel free to contact us by email at&nbsp;<a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="93f2e3f8f2fffaf4fbe7fefce7fafcfde0d3f4fef2faffbdf0fcfe">[email&nbsp;protected]</a></p>



<h2 class="kt-adv-heading54_4874ef-71 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_4874ef-71">Disclaimers for alightmotionsapp.com</h2>



<p class="kt-adv-heading54_294651-89 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_294651-89">All the information on this website— <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a> —is published in good faith and for general information purposes only. alightmotionsapp.com does not make any warranties about the completeness, reliability, or accuracy of this information. Any action you take upon the information you find on this website (alightmotionsapp.com) is strictly at your own risk. alightmotionsapp.com will not be liable for any losses and/or damages related to using our website. </p>



<p class="kt-adv-heading54_ea88eb-29 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_ea88eb-29">You can visit other websites from our website by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and occur before we can remove a link that may have gone ‘bad’.</p>



<p class="kt-adv-heading54_716f19-a9 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_716f19-a9">Please also be aware that when you leave our website, other sites may have different privacy policies and terms beyond our control. Please check the Privacy Policies of these sites and their “Terms of Service” before engaging in any business or uploading any information.</p>



<h2 class="kt-adv-heading54_4221c1-13 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_4221c1-13">Consent</h2>



<p class="kt-adv-heading54_08a395-09 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_08a395-09">Using our website, you consent to our disclaimer and agree to its terms.</p>



<h2 class="kt-adv-heading54_474e3f-c1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_474e3f-c1">Update</h2>



<p class="kt-adv-heading54_863e35-a1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading54_863e35-a1">Should we update, amend, or make any changes to this document, we will prominently post those changes here.</p>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>

        <?php the_content(); ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<p>Tags: ', ', ', '</p>'); ?>
        <?php the_category(); ?>
    </footer>
</article>

<?php get_footer(); ?>