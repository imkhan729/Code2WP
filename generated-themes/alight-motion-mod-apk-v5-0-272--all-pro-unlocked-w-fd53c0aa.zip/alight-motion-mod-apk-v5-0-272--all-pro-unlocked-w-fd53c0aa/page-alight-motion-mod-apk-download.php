<?php
/**
 * Template for Alight Motion Mod APK Download - Latest Version (Unlocked Premium Features)Toggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: alight-motion-mod-apk-download.html
 */

get_header(); ?>

<div class="page-content">
    
<div id="wrapper" class="site wp-site-blocks">
			<a class="skip-link screen-reader-text scroll-ignore" href="#main">Skip to content</a>
		<!-- #masthead -->

	<div id="inner-wrap" class="wrap hfeed kt-clear">
		<div id="primary" class="content-area">
	<div class="content-container site-container">
		<main id="main" class="site-main" role="main">
						<div class="content-wrap">
				<article id="post-46" class="entry content-bg single-entry post-46 page type-page status-publish hentry">
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id46_9e14cc-43 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_228322-5d"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading46_0660c8-7c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_0660c8-7c"><strong>Alight Motion Mod APK Download – Latest Version (Unlocked Premium Features</strong>)</h1>
</div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_db716d-01 alignnone kt-row-has-bg am-child-hero-section wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-2-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_45df64-e6 kb-section-dir-vertical kb-section-sm-dir-horizontal"><div class="kt-inside-inner-col">
<figure class="wp-block-kadence-image kb-image46_0bc559-fd size-thumbnail"><img decoding="async" src="https://alightmotions.webakesweb.com/wp-content/uploads/2024/04/logo-150x150.webp" alt="" class="kb-img wp-image-438"></figure>


<div class="kb-row-layout-wrap kb-row-layout-id46_3b4fa9-cd alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-2-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top">

<div class="wp-block-kadence-column kadence-column46_2f1fba-70"><div class="kt-inside-inner-col"><p class="kt-adv-heading46_7ccb3b-27 wp-block-kadence-advancedheading kt-adv-heading-has-icon has-theme-palette9-color has-text-color" data-kb-block="kb-adv-heading46_7ccb3b-27"><span class="kb-adv-text-inner"><strong>4.</strong>2</span><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-ic_star kb-adv-heading-icon-side-right"><svg viewBox="0 0 8 8" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4 0l-1 3h-3l2.5 2-1 3 2.5-2 2.5 2-1-3 2.5-2h-3l-1-3z"></path></svg></span></p>


<p class="kt-adv-heading46_80e6ae-58 wp-block-kadence-advancedheading has-theme-palette-9-color has-text-color" data-kb-block="kb-adv-heading46_80e6ae-58">Ratings</p>
</div></div>



<div class="wp-block-kadence-column kadence-column46_9b6dc2-c8"><div class="kt-inside-inner-col"><p class="kt-adv-heading46_b6e953-cd wp-block-kadence-advancedheading kt-adv-heading-has-icon has-theme-palette9-color has-text-color" data-kb-block="kb-adv-heading46_b6e953-cd"><span class="kb-adv-text-inner"><strong>100M</strong></span><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fe_plus kb-adv-heading-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg></span></p>


<p class="kt-adv-heading46_eadd5b-d3 wp-block-kadence-advancedheading has-theme-palette-9-color has-text-color" data-kb-block="kb-adv-heading46_eadd5b-d3">Downloads</p>
</div></div>

</div></div></div></div>



<div class="wp-block-kadence-column kadence-column46_ef2d2f-d2"><div class="kt-inside-inner-col">
<h2 class="kt-adv-heading46_3f81c6-08 wp-block-kadence-advancedheading has-theme-palette-9-color has-text-color" data-kb-block="kb-adv-heading46_3f81c6-08">Download Alight Motion APk</h2>



<p class="kt-adv-heading46_b79c1a-96 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_b79c1a-96"><span data-strings="[&quot;Keyframes Animations&quot;,&quot;No Ads&quot;,&quot;No Lag&quot;,&quot;User-Friendly&quot;,&quot;Easy To Use&quot;,&quot;Premium Effects&quot;,&quot;Text Fonts&quot;,&quot;No Watermark&quot;]" data-cursor-char="|" class="kt-typed-text">Alight Motion Mod APK</span></p>



<p class="kt-adv-heading46_bf5c25-4d wp-block-kadence-advancedheading has-theme-palette-9-color has-text-color" data-kb-block="kb-adv-heading46_bf5c25-4d">V5.0.272 – Latest Version</p>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_b290c7-de"><a class="kb-button kt-button button kb-btn46_9742cb-3f kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.272.1028368_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>
</div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_8d0f95-a0 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_800a6d-7b"><div class="kt-inside-inner-col">
<p class="kt-adv-heading46_27d805-fb wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_27d805-fb">Review the list of all <strong>Alight Motion Mod APK </strong>versions we offer below. You must pick the version you want and click the download button. They include the latest upgrade and old mod versions, and you will get unlocked features and impressive additional effects that take your editing to the next level with comfort and simplicity</p>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_55a124-6e"><a class="kb-button kt-button button kb-btn46_8736cb-fa kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.272.1028368_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.272</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_c21dd1-b4"><a class="kb-button kt-button button kb-btn46_3b4ae7-f1 kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.271.1002592_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.271</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_7a7292-bc"><a class="kb-button kt-button button kb-btn46_c198ce-a4 kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.270.1002578_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.270</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_7309ed-a4"><a class="kb-button kt-button button kb-btn46_90673b-25 kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.269.1002556_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.269</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_800ba5-d5"><a class="kb-button kt-button button kb-btn46_0bd792-be kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.259.1002336_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.259</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_03f781-b1"><a class="kb-button kt-button button kb-btn46_ed8e1c-6b kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://dl.alightmotionsapp.com/alight_motion_v5.0.256.1002290_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK v5.0.256</span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<p class="kt-adv-heading46_07efe1-05 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_07efe1-05">For more details on the mod version, <a href="https://alightmotionsapp.com/" data-type="link" data-id="https://alightmotionsapp.com/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Click here</mark></strong></a></p>



<figure class="wp-block-kadence-image kb-image46_081124-87 size-full"><img decoding="async" width="1500" height="725" src="https://alightmotionsapp.com/wp-content/uploads/2024/04/alight-motion-pro-download.webp" alt="Alight Motion Pro Download" class="kb-img wp-image-113" srcset="https://alightmotionsapp.com/wp-content/uploads/2024/04/alight-motion-pro-download.webp 1500w, https://alightmotionsapp.com/wp-content/uploads/2024/04/alight-motion-pro-download-300x145.webp 300w, https://alightmotionsapp.com/wp-content/uploads/2024/04/alight-motion-pro-download-1024x495.webp 1024w, https://alightmotionsapp.com/wp-content/uploads/2024/04/alight-motion-pro-download-768x371.webp 768w" sizes="(max-width: 1500px) 100vw, 1500px"></figure>
</div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_139155-df alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_381329-2a"><div class="kt-inside-inner-col"><h2 class="kt-adv-heading46_b1072c-30 wp-block-kadence-advancedheading kt-adv-heading-has-icon am-heading-style1" data-kb-block="kb-adv-heading46_b1072c-30"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fas_hand-point-right kb-adv-heading-icon-side-left"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M512 199.652c0 23.625-20.65 43.826-44.8 43.826h-99.851c16.34 17.048 18.346 49.766-6.299 70.944 14.288 22.829 2.147 53.017-16.45 62.315C353.574 425.878 322.654 448 272 448c-2.746 0-13.276-.203-16-.195-61.971.168-76.894-31.065-123.731-38.315C120.596 407.683 112 397.599 112 385.786V214.261l.002-.001c.011-18.366 10.607-35.889 28.464-43.845 28.886-12.994 95.413-49.038 107.534-77.323 7.797-18.194 21.384-29.084 40-29.092 34.222-.014 57.752 35.098 44.119 66.908-3.583 8.359-8.312 16.67-14.153 24.918H467.2c23.45 0 44.8 20.543 44.8 43.826zM96 200v192c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V200c0-13.255 10.745-24 24-24h48c13.255 0 24 10.745 24 24zM68 368c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"></path></svg></span><span class="kb-adv-text-inner">Alight Motion Pro</span></h2>


<p class="kt-adv-heading46_5c0d0a-df wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_5c0d0a-df"><strong>Alight Motion Pro</strong> will provide a complete and fully unlocked premium experience. The <a href="https://en.wikipedia.org/wiki/Key_frame" rel="noopener"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">keyframes </mark></strong></a>feature is one of the Pro versions of <strong>Alight Motion APK without watermark’</strong>s tools. KeyFrame is capable of editing video at a frame-by-frame level. The color change feature is also available. It allows you to change the colours of some things in the scanned object and make more modifications. This can be done on all platforms, including iPhone and <a href="https://alightmotionsapp.com/alight-motion-for-ios/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">IOS</mark></strong></a>, Android, and <a href="https://alightmotionsapp.com/alight-motion-for-pc/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">PC</mark></strong></a>.</p>



<p class="kt-adv-heading46_86c27d-fb wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_86c27d-fb">Edit and animate video content like a pro with&nbsp;<strong><mark class="kt-highlight"><mark style="background-color:rgba(0, 0, 0, 0);color:#060606" class="has-inline-color">Alight Motion Mod APK</mark></mark>,</strong>&nbsp;offering a magical experience on the device. Craft masterpieces, turning raw footage into immersive art, and showcase your inner creative editor.</p>
</div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_c51679-8b alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top">

<div class="wp-block-kadence-column kadence-column46_2b0591-6c"><div class="kt-inside-inner-col"><div class="kb-row-layout-wrap kb-row-layout-id46_052df6-92 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-2-columns kt-row-layout-row kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_7f20ee-3f"><div class="kt-inside-inner-col"><h2 class="kt-adv-heading46_08cebb-44 wp-block-kadence-advancedheading kt-adv-heading-has-icon am-heading-style1" data-kb-block="kb-adv-heading46_08cebb-44"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fas_hand-point-right kb-adv-heading-icon-side-left"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M512 199.652c0 23.625-20.65 43.826-44.8 43.826h-99.851c16.34 17.048 18.346 49.766-6.299 70.944 14.288 22.829 2.147 53.017-16.45 62.315C353.574 425.878 322.654 448 272 448c-2.746 0-13.276-.203-16-.195-61.971.168-76.894-31.065-123.731-38.315C120.596 407.683 112 397.599 112 385.786V214.261l.002-.001c.011-18.366 10.607-35.889 28.464-43.845 28.886-12.994 95.413-49.038 107.534-77.323 7.797-18.194 21.384-29.084 40-29.092 34.222-.014 57.752 35.098 44.119 66.908-3.583 8.359-8.312 16.67-14.153 24.918H467.2c23.45 0 44.8 20.543 44.8 43.826zM96 200v192c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V200c0-13.255 10.745-24 24-24h48c13.255 0 24 10.745 24 24zM68 368c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"></path></svg></span><span class="kb-adv-text-inner">Key Feature of Premium Version Alight Motion Pro</span></h2></div></div>



<div class="wp-block-kadence-column kadence-column46_1d3bae-00"><div class="kt-inside-inner-col"><div class="kb-row-layout-wrap kb-row-layout-id46_ac9d4f-2e alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top">

<div class="wp-block-kadence-column kadence-column46_a04700-44"><div class="kt-inside-inner-col">
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items46_5a0a8c-73 kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list">
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_31f01a-a5"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Add multiple layers</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_a2b1cb-28"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Vector and bitmap support</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_514a43-e0"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">160+ basic effect building blocks</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_b864fc-67"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Keyframe animation</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_dfe6f0-40"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Link parent and child layers&nbsp;</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_d1ece3-74"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">No Watermark</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_c395f7-d3"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Use of Camera</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_f58aa7-9a"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Velocity-based motion blur</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_811c93-c9"><span class="kb-svg-icon-wrap kb-svg-icon-fe_checkCircle kt-svg-icon-list-single"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg></span><span class="kt-svg-icon-list-text">Export MP4 video, GIF animation, and PNG sequences</span></li>
</ul></div>
</div></div>

</div></div></div></div>

</div></div></div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_63f73f-a0 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top">

<div class="wp-block-kadence-column kadence-column46_859d7f-00"><div class="kt-inside-inner-col"><div class="kb-row-layout-wrap kb-row-layout-id46_97e874-d1 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-2-columns kt-row-layout-row kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_a61588-31"><div class="kt-inside-inner-col"><h2 class="kt-adv-heading46_0e6639-14 wp-block-kadence-advancedheading kt-adv-heading-has-icon am-heading-style1" data-kb-block="kb-adv-heading46_0e6639-14"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fas_hand-point-right kb-adv-heading-icon-side-left"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M512 199.652c0 23.625-20.65 43.826-44.8 43.826h-99.851c16.34 17.048 18.346 49.766-6.299 70.944 14.288 22.829 2.147 53.017-16.45 62.315C353.574 425.878 322.654 448 272 448c-2.746 0-13.276-.203-16-.195-61.971.168-76.894-31.065-123.731-38.315C120.596 407.683 112 397.599 112 385.786V214.261l.002-.001c.011-18.366 10.607-35.889 28.464-43.845 28.886-12.994 95.413-49.038 107.534-77.323 7.797-18.194 21.384-29.084 40-29.092 34.222-.014 57.752 35.098 44.119 66.908-3.583 8.359-8.312 16.67-14.153 24.918H467.2c23.45 0 44.8 20.543 44.8 43.826zM96 200v192c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V200c0-13.255 10.745-24 24-24h48c13.255 0 24 10.745 24 24zM68 368c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"></path></svg></span><span class="kb-adv-text-inner">What’s New Alight Motion v5.0.237</span></h2>


<p class="kt-adv-heading46_968ef9-03 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_968ef9-03">After the new update, many bugs were fixed, and performance improvements were made. You can experience this after installing the latest version and some new features in your editing. Here are the new features listed below:</p>
</div></div>



<div class="wp-block-kadence-column kadence-column46_461183-6b"><div class="kt-inside-inner-col"><div class="kb-row-layout-wrap kb-row-layout-id46_68507d-ec alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top">

<div class="wp-block-kadence-column kadence-column46_0c3240-19"><div class="kt-inside-inner-col">
<div class="wp-block-kadence-iconlist kt-svg-icon-list-items kt-svg-icon-list-items46_319869-4e kt-svg-icon-list-columns-1 alignnone"><ul class="kt-svg-icon-list">
<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_07a5d2-7d"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Multiple layers of graphics, video, and audio</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_8dae7e-b6"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Vector and bitmap support</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_fdeff9-d4"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">160+ basic effect building blocks that can be combined to create sophisticated visual effects</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_ab8440-39"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Keyframe animation available for all settings</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_276b2b-9b"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Link parent and child layers and rig character joints&nbsp;</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_54bd04-06"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Cameras that pan, zoom, and support focus blur and fog</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_20977a-d4"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Grouping and Masking</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_f54572-fd"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Color Adjustment</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_0df811-00"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Animation easing for more fluid motion: Pick from presets or build your own timing curves</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_be1adc-10"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Export MP4 video, GIF animation, PNG sequences, and stills</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_abcc50-0e"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Share project packages with others</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_03cfc9-7a"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Solid color and gradient fill effects</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_0342a5-cf"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Border, shadow, and stroke effects</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_9a0e0b-ee"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Custom font support</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_989fbf-df"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Copy and paste entire layers or just their style</span></li>



<li class="wp-block-kadence-listitem kt-svg-icon-list-item-wrap kt-svg-icon-list-item-46_8ab265-04"><span class="kb-svg-icon-wrap kb-svg-icon-fas_check-double kt-svg-icon-list-single"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M504.5 171.95l-36.2-36.41c-10-10.05-26.21-10.05-36.2 0L192 377.02 79.9 264.28c-10-10.06-26.21-10.06-36.2 0L7.5 300.69c-10 10.05-10 26.36 0 36.41l166.4 167.36c10 10.06 26.21 10.06 36.2 0l294.4-296.09c10-10.06 10-26.36 0-36.42zM166.57 282.71c6.84 7.02 18.18 7.02 25.21.18L403.85 72.62c7.02-6.84 7.02-18.18.18-25.21L362.08 5.29c-6.84-7.02-18.18-7.02-25.21-.18L179.71 161.19l-68.23-68.77c-6.84-7.02-18.18-7.02-25.2-.18l-42.13 41.77c-7.02 6.84-7.02 18.18-.18 25.2l122.6 123.5z"></path></svg></span><span class="kt-svg-icon-list-text">Save your favorite elements for easy re-use in future projects</span></li>
</ul></div>
</div></div>

</div></div></div></div>

</div></div></div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_14f1fc-d6 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_bd1432-6f"><div class="kt-inside-inner-col"><h2 class="kt-adv-heading46_afcad1-be wp-block-kadence-advancedheading kt-adv-heading-has-icon am-heading-style1" data-kb-block="kb-adv-heading46_afcad1-be"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fas_hand-point-right kb-adv-heading-icon-side-left"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M512 199.652c0 23.625-20.65 43.826-44.8 43.826h-99.851c16.34 17.048 18.346 49.766-6.299 70.944 14.288 22.829 2.147 53.017-16.45 62.315C353.574 425.878 322.654 448 272 448c-2.746 0-13.276-.203-16-.195-61.971.168-76.894-31.065-123.731-38.315C120.596 407.683 112 397.599 112 385.786V214.261l.002-.001c.011-18.366 10.607-35.889 28.464-43.845 28.886-12.994 95.413-49.038 107.534-77.323 7.797-18.194 21.384-29.084 40-29.092 34.222-.014 57.752 35.098 44.119 66.908-3.583 8.359-8.312 16.67-14.153 24.918H467.2c23.45 0 44.8 20.543 44.8 43.826zM96 200v192c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V200c0-13.255 10.745-24 24-24h48c13.255 0 24 10.745 24 24zM68 368c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"></path></svg></span><span class="kb-adv-text-inner">Download and install Alight Motion Pro APK</span></h2>


<p class="kt-adv-heading46_dfa76c-c8 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_dfa76c-c8">Click the button below to download the <strong>Alight Motion APK</strong> file to your device. After successfully downloading is done. Go through to the download folder and open the apk file. Before installation, you have to turn on ‘Unknow source’ from the device settings and proceed, click on the install button to finish the installation. For a complete guide <a href="https://alightmotionsapp.com/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Click Here</mark></strong></a></p>



<div class="wp-block-kadence-image kb-image46_b5bbb2-79"><figure class="aligncenter size-thumbnail"><img decoding="async" src="https://alightmotions.webakesweb.com/wp-content/uploads/2024/04/cropped-logo-150x150.webp" alt="" class="kb-img wp-image-439"></figure></div>



<p class="kt-adv-heading46_55c77d-ea wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_55c77d-ea">v5.0.256 || 131MB</p>



<div class="wp-block-kadence-advancedbtn kb-buttons-wrap kb-btns46_95543b-9e"><a class="kb-button kt-button button kb-btn46_0022dd-ed kt-btn-size-standard kt-btn-width-type-auto kb-btn-global-fill kt-btn-has-text-true kt-btn-has-svg-true wp-block-kadence-singlebtn" href="https://get.alightmotionsapp.com/alight_motion_v5.0.256.1002290_mod_alightmotionsapp.com.apk"><span class="kt-btn-inner-text">Download APK </span><span class="kb-svg-icon-wrap kb-svg-icon-fe_download kt-btn-icon-side-right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg></span></a></div>



<p class="kt-adv-heading46_a646fd-ac wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_a646fd-ac">For PC, the installation process of the apk file is different, and it requires some special commands and tools to execute the <strong>Alight Motion Mod</strong> file, you don’t have to worry about just following how to download <a href="https://alightmotionsapp.com/alight-motion-for-pc/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Alight Motion for PC</mark></strong></a></p>



<p class="kt-adv-heading46_61faef-8e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading46_61faef-8e">The installation process for iOS is also different and executes exceptional security. Just follow these instructions to install <a href="https://alightmotionsapp.com/alight-motion-for-ios/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Alight Motion for iOS</mark></strong></a>.</p>
</div></div>

</div></div>

<div class="kb-row-layout-wrap kb-row-layout-id46_3c7966-58 alignfull has-theme-palette9-background-color kt-row-has-bg wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column46_8a819b-4f kadence-column_c5113a-9d"><div class="kt-inside-inner-col"><h4 class="kt-adv-heading46_da87e1-c4 wp-block-kadence-advancedheading kt-adv-heading-has-icon am-heading-style1 has-theme-palette9-color has-text-color" data-kb-block="kb-adv-heading46_da87e1-c4"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fas_hand-point-right kb-adv-heading-icon-side-left"><svg viewBox="0 0 512 512" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M512 199.652c0 23.625-20.65 43.826-44.8 43.826h-99.851c16.34 17.048 18.346 49.766-6.299 70.944 14.288 22.829 2.147 53.017-16.45 62.315C353.574 425.878 322.654 448 272 448c-2.746 0-13.276-.203-16-.195-61.971.168-76.894-31.065-123.731-38.315C120.596 407.683 112 397.599 112 385.786V214.261l.002-.001c.011-18.366 10.607-35.889 28.464-43.845 28.886-12.994 95.413-49.038 107.534-77.323 7.797-18.194 21.384-29.084 40-29.092 34.222-.014 57.752 35.098 44.119 66.908-3.583 8.359-8.312 16.67-14.153 24.918H467.2c23.45 0 44.8 20.543 44.8 43.826zM96 200v192c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24V200c0-13.255 10.745-24 24-24h48c13.255 0 24 10.745 24 24zM68 368c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"></path></svg></span><span class="kb-adv-text-inner">FAQs</span></h4>


<div class="wp-block-kadence-accordion alignnone"><div class="kt-accordion-wrap kt-accordion-id46_dcf386-fe kt-accordion-has-11-panes kt-active-pane-7 kt-accordion-block kt-pane-header-alignment-left kt-accodion-icon-style-arrow kt-accodion-icon-side-right" style="max-width:none"><div class="kt-accordion-inner-wrap" data-allow-multiple-open="true" data-start-open="7">
<div class="wp-block-kadence-pane kt-accordion-pane kt-accordion-pane-8 kt-pane46_0626ab-c0"><h3 class="kt-accordion-header-wrap"><button class="kt-blocks-accordion-header kt-acccordion-button-label-show" type="button"><span class="kt-blocks-accordion-title-wrap"><span class="kt-blocks-accordion-title"><strong>How do you download the latest version of Alight Motion Pro APK?</strong></span></span><span class="kt-blocks-accordion-icon-trigger"></span></button></h3><div class="kt-accordion-panel kt-accordion-panel-hidden"><div class="kt-accordion-panel-inner"><p class="kt-adv-heading46_d849a9-3a wp-block-kadence-advancedheading kt-adv-heading-has-icon" data-kb-block="kb-adv-heading46_d849a9-3a"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fe_cornerDownRight kb-adv-heading-icon-side-left"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg></span><span class="kb-adv-text-inner">After visiting my official site, you can download the latest pro-unlocked version of Alight Motion; I have already listed all the download guides with premium features for you above.</span></p></div></div></div>



<div class="wp-block-kadence-pane kt-accordion-pane kt-accordion-pane-9 kt-pane46_10893a-9d"><h3 class="kt-accordion-header-wrap"><button class="kt-blocks-accordion-header kt-acccordion-button-label-show" type="button"><span class="kt-blocks-accordion-title-wrap"><span class="kt-blocks-accordion-title"><strong>How can I acquire a free version of Alight Motion Pro on my Android device?</strong></span></span><span class="kt-blocks-accordion-icon-trigger"></span></button></h3><div class="kt-accordion-panel kt-accordion-panel-hidden"><div class="kt-accordion-panel-inner"><p class="kt-adv-heading46_d61a8a-15 wp-block-kadence-advancedheading kt-adv-heading-has-icon" data-kb-block="kb-adv-heading46_d61a8a-15"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fe_cornerDownRight kb-adv-heading-icon-side-left"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg></span><span class="kb-adv-text-inner">You can acquire the Alight Motion Pro on your <strong><a href="https://www.android.com/" rel="noopener"><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">Android </mark></a></strong>device by clicking the download button to download the mod apk file on your device. Then, you can install the file and enjoy all the unlocked features. follow the installation guide <a href="https://alightmotionsapp.com/"><strong>Here</strong></a></span></p></div></div></div>



<div class="wp-block-kadence-pane kt-accordion-pane kt-accordion-pane-1 kt-pane46_7fd1cb-53"><h3 class="kt-accordion-header-wrap"><button class="kt-blocks-accordion-header kt-acccordion-button-label-show" type="button"><span class="kt-blocks-accordion-title-wrap"><span class="kt-blocks-accordion-title"><strong>Is Alight Motion Mod APK for iOS Safe to download?</strong></span></span><span class="kt-blocks-accordion-icon-trigger"></span></button></h3><div class="kt-accordion-panel kt-accordion-panel-hidden"><div class="kt-accordion-panel-inner"><p class="kt-adv-heading46_69b262-42 wp-block-kadence-advancedheading kt-adv-heading-has-icon" data-kb-block="kb-adv-heading46_69b262-42"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fe_cornerDownRight kb-adv-heading-icon-side-left"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg></span><span class="kb-adv-text-inner">Yes, the <strong>Alight Motion Mod APK</strong> Version for your iOS iPhone is safe and malware-free to download and use for animation projects without a watermark. To install the modded version, follow my installation guidelines, which include particular instructions in the <a href="https://alightmotionsapp.com/alight-motion-for-ios/"><strong><mark style="background-color:rgba(0, 0, 0, 0);color:#2196f3" class="has-inline-color">article</mark></strong></a>.</span></p></div></div></div>



<div class="wp-block-kadence-pane kt-accordion-pane kt-accordion-pane-11 kt-pane46_0bd355-14"><h3 class="kt-accordion-header-wrap"><button class="kt-blocks-accordion-header kt-acccordion-button-label-show" type="button"><span class="kt-blocks-accordion-title-wrap"><span class="kt-blocks-accordion-title"><strong>How do I remove the watermark on the alight motion?</strong></span></span><span class="kt-blocks-accordion-icon-trigger"></span></button></h3><div class="kt-accordion-panel kt-accordion-panel-hidden"><div class="kt-accordion-panel-inner"><p class="kt-adv-heading46_52035f-20 wp-block-kadence-advancedheading kt-adv-heading-has-icon" data-kb-block="kb-adv-heading46_52035f-20"><span class="kb-svg-icon-wrap kb-adv-heading-icon kb-svg-icon-fe_cornerDownRight kb-adv-heading-icon-side-left"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><polyline points="15 10 20 15 15 20"></polyline><path d="M4 4v7a4 4 0 0 0 4 4h12"></path></svg></span><span class="kb-adv-text-inner">You can remove the Alight Motion watermark for free after downloading the <strong>Pro Mod Apk </strong>version from my site above; when you open the mod version after installing, you will never face any premium locks and watermark on video issues.</span></p></div></div></div>
</div></div></div>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>
</article><!-- #post-46 -->

			</div>
					</main><!-- #main -->
			</div>
</div><!-- #primary -->
	</div><!-- #inner-wrap -->
	<!-- #colophon -->

</div><!-- #wrapper -->

			<script type="9bc86d40bf7b88106938a260-text/javascript">document.documentElement.style.setProperty('--scrollbar-offset', window.innerWidth - document.documentElement.clientWidth + 'px' );</script>
			<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"\/*"},{"not":{"href_matches":["\/wp-*.php","\/wp-admin\/*","\/wp-content\/uploads\/*","\/wp-content\/*","\/wp-content\/plugins\/*","\/wp-content\/themes\/kadence\/*","\/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<a id="kt-scroll-up" tabindex="-1" aria-hidden="true" aria-label="Scroll to top" href="#wrapper" class="kadence-scroll-to-top scroll-up-wrap scroll-ignore scroll-up-side-right scroll-up-style-filled vs-lg-true vs-md-true vs-sm-false"><span class="kadence-svg-iconset"><svg aria-hidden="true" class="kadence-svg-icon kadence-arrow-up2-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"><title>Scroll to top</title><path d="M25.172 15.172c0 0.531-0.219 1.031-0.578 1.406l-1.172 1.172c-0.375 0.375-0.891 0.594-1.422 0.594s-1.047-0.219-1.406-0.594l-4.594-4.578v11c0 1.125-0.938 1.828-2 1.828h-2c-1.062 0-2-0.703-2-1.828v-11l-4.594 4.578c-0.359 0.375-0.875 0.594-1.406 0.594s-1.047-0.219-1.406-0.594l-1.172-1.172c-0.375-0.375-0.594-0.875-0.594-1.406s0.219-1.047 0.594-1.422l10.172-10.172c0.359-0.375 0.875-0.578 1.406-0.578s1.047 0.203 1.422 0.578l10.172 10.172c0.359 0.375 0.578 0.891 0.578 1.422z"></path>
				</svg></span></a><button id="kt-scroll-up-reader" href="#wrapper" aria-label="Scroll to top" class="kadence-scroll-to-top scroll-up-wrap scroll-ignore scroll-up-side-right scroll-up-style-filled vs-lg-true vs-md-true vs-sm-false"><span class="kadence-svg-iconset"><svg aria-hidden="true" class="kadence-svg-icon kadence-arrow-up2-svg" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" width="26" height="28" viewBox="0 0 26 28"><title>Scroll to top</title><path d="M25.172 15.172c0 0.531-0.219 1.031-0.578 1.406l-1.172 1.172c-0.375 0.375-0.891 0.594-1.422 0.594s-1.047-0.219-1.406-0.594l-4.594-4.578v11c0 1.125-0.938 1.828-2 1.828h-2c-1.062 0-2-0.703-2-1.828v-11l-4.594 4.578c-0.359 0.375-0.875 0.594-1.406 0.594s-1.047-0.219-1.406-0.594l-1.172-1.172c-0.375-0.375-0.594-0.875-0.594-1.406s0.219-1.047 0.594-1.422l10.172-10.172c0.359-0.375 0.875-0.578 1.406-0.578s1.047 0.203 1.422 0.578l10.172 10.172c0.359 0.375 0.578 0.891 0.578 1.422z"></path>
				</svg></span></button>	<div id="mobile-drawer" class="popup-drawer popup-drawer-layout-sidepanel popup-drawer-animation-fade popup-drawer-side-right" data-drawer-target-string="#mobile-drawer">
		<div class="drawer-overlay" data-drawer-target-string="#mobile-drawer"></div>
		<div class="drawer-inner">
						<div class="drawer-header">
				<button class="menu-toggle-close drawer-toggle" aria-label="Close menu" data-toggle-target="#mobile-drawer" data-toggle-body-class="showing-popup-drawer-from-right" aria-expanded="false" data-set-focus=".menu-toggle-open">
					<span class="toggle-close-bar"></span>
					<span class="toggle-close-bar"></span>
				</button>
			</div>
			<div class="drawer-content mobile-drawer-content content-align-left content-valign-top">
								<div class="site-header-item site-header-focus-item site-header-item-mobile-navigation mobile-navigation-layout-stretch-false" data-section="kadence_customizer_mobile_navigation">
		<!-- #site-navigation -->
	</div><!-- data-section="mobile_navigation" -->
							</div>
		</div>
	</div>
	<script src="https://alightmotionsapp.com/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script src="https://alightmotionsapp.com/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script id="wp-i18n-js-after" type="9bc86d40bf7b88106938a260-text/javascript">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
</script>
<script src="https://alightmotionsapp.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.0.2" id="swv-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script id="contact-form-7-js-before" type="9bc86d40bf7b88106938a260-text/javascript">
var wpcf7 = {
    "api": {
        "root": "https:\/\/alightmotionsapp.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
</script>
<script src="https://alightmotionsapp.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.0.2" id="contact-form-7-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script id="rocket-browser-checker-js-after" type="9bc86d40bf7b88106938a260-text/javascript">
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
</script>
<script id="rocket-preload-links-js-extra" type="9bc86d40bf7b88106938a260-text/javascript">
var RocketPreloadLinksConfig = {"excludeUris":"\/(?:.+\/)?feed(?:\/(?:.+\/?)?)?$|\/(?:.+\/)?embed\/|\/(index.php\/)?(.*)wp-json(\/.*|$)|\/refer\/|\/go\/|\/recommend\/|\/recommends\/","usesTrailingSlash":"1","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https:\/\/alightmotionsapp.com","onHoverDelay":"100","rateThrottle":"3"};
</script>
<script id="rocket-preload-links-js-after" type="9bc86d40bf7b88106938a260-text/javascript">
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());
</script>
<script id="kadence-navigation-js-extra" type="9bc86d40bf7b88106938a260-text/javascript">
var kadenceConfig = {"screenReader":{"expand":"Child menu","expandOf":"Child menu of","collapse":"Child menu","collapseOf":"Child menu of"},"breakPoints":{"desktop":"1024","tablet":768},"scrollOffset":"0"};
</script>
<script src="https://alightmotionsapp.com/wp-content/themes/kadence/assets/js/navigation.min.js?ver=1.2.4" id="kadence-navigation-js" async="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script src="https://alightmotionsapp.com/wp-content/plugins/kadence-blocks/includes/assets/js/kt-accordion.min.js?ver=3.4.5" id="kadence-blocks-accordion-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script async="" data-no-optimize="1" src="https://alightmotionsapp.com/wp-content/plugins/perfmatters/vendor/instant-page/pminstantpage.min.js?ver=2.2.6" id="perfmatters-instant-page-js" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script src="https://alightmotionsapp.com/wp-content/plugins/kadence-blocks/includes/assets/js/typed.min.js?ver=3.4.5" id="kadence-blocks-typed-js-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script src="https://alightmotionsapp.com/wp-content/plugins/kadence-blocks/includes/assets/js/kb-advanced-heading.min.js?ver=3.4.5" id="kadence-blocks-advancedheading-js" defer="" type="9bc86d40bf7b88106938a260-text/javascript"></script>
<script id="perfmatters-delayed-scripts-js" type="9bc86d40bf7b88106938a260-text/javascript">const pmDelayClick=false;const pmDelayTimer=setTimeout(pmTriggerDOMListener,10*1000);const pmUserInteractions=["keydown","mousedown","mousemove","wheel","touchmove","touchstart","touchend"],pmDelayedScripts={normal:[],defer:[],async:[]},jQueriesArray=[],pmInterceptedClicks=[];var pmDOMLoaded=!1,pmClickTarget="";function pmTriggerDOMListener(){"undefined"!=typeof pmDelayTimer&&clearTimeout(pmDelayTimer),pmUserInteractions.forEach(function(e){window.removeEventListener(e,pmTriggerDOMListener,{passive:!0})}),document.removeEventListener("visibilitychange",pmTriggerDOMListener),"loading"===document.readyState?document.addEventListener("DOMContentLoaded",pmTriggerDelayedScripts):pmTriggerDelayedScripts()}async function pmTriggerDelayedScripts(){pmDelayEventListeners(),pmDelayJQueryReady(),pmProcessDocumentWrite(),pmSortDelayedScripts(),pmPreloadDelayedScripts(),await pmLoadDelayedScripts(pmDelayedScripts.normal),await pmLoadDelayedScripts(pmDelayedScripts.defer),await pmLoadDelayedScripts(pmDelayedScripts.async),await pmTriggerEventListeners(),document.querySelectorAll("link[data-pmdelayedstyle]").forEach(function(e){e.setAttribute("href",e.getAttribute("data-pmdelayedstyle"))}),window.dispatchEvent(new Event("perfmatters-allScriptsLoaded")),pmReplayClicks()}function pmDelayEventListeners(){let e={};function t(t,r){function n(r){return e[t].delayedEvents.indexOf(r)>=0?"perfmatters-"+r:r}e[t]||(e[t]={originalFunctions:{add:t.addEventListener,remove:t.removeEventListener},delayedEvents:[]},t.addEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.add.apply(t,arguments)},t.removeEventListener=function(){arguments[0]=n(arguments[0]),e[t].originalFunctions.remove.apply(t,arguments)}),e[t].delayedEvents.push(r)}function r(e,t){let r=e[t];Object.defineProperty(e,t,{get:r||function(){},set:function(r){e["perfmatters"+t]=r}})}t(document,"DOMContentLoaded"),t(window,"DOMContentLoaded"),t(window,"load"),t(window,"pageshow"),t(document,"readystatechange"),r(document,"onreadystatechange"),r(window,"onload"),r(window,"onpageshow")}function pmDelayJQueryReady(){let e=window.jQuery;Object.defineProperty(window,"jQuery",{get:()=>e,set(t){if(t&&t.fn&&!jQueriesArray.includes(t)){t.fn.ready=t.fn.init.prototype.ready=function(e){pmDOMLoaded?e.bind(document)(t):document.addEventListener("perfmatters-DOMContentLoaded",function(){e.bind(document)(t)})};let r=t.fn.on;t.fn.on=t.fn.init.prototype.on=function(){if(this[0]===window){function e(e){return e=(e=(e=e.split(" ")).map(function(e){return"load"===e||0===e.indexOf("load.")?"perfmatters-jquery-load":e})).join(" ")}"string"==typeof arguments[0]||arguments[0]instanceof String?arguments[0]=e(arguments[0]):"object"==typeof arguments[0]&&Object.keys(arguments[0]).forEach(function(t){delete Object.assign(arguments[0],{[e(t)]:arguments[0][t]})[t]})}return r.apply(this,arguments),this},jQueriesArray.push(t)}e=t}})}function pmProcessDocumentWrite(){let e=new Map;document.write=document.writeln=function(t){var r=document.currentScript,n=document.createRange();let a=e.get(r);void 0===a&&(a=r.nextSibling,e.set(r,a));var i=document.createDocumentFragment();n.setStart(i,0),i.appendChild(n.createContextualFragment(t)),r.parentElement.insertBefore(i,a)}}function pmSortDelayedScripts(){document.querySelectorAll("script[type=pmdelayedscript]").forEach(function(e){e.hasAttribute("src")?e.hasAttribute("defer")&&!1!==e.defer?pmDelayedScripts.defer.push(e):e.hasAttribute("async")&&!1!==e.async?pmDelayedScripts.async.push(e):pmDelayedScripts.normal.push(e):pmDelayedScripts.normal.push(e)})}function pmPreloadDelayedScripts(){var e=document.createDocumentFragment();[...pmDelayedScripts.normal,...pmDelayedScripts.defer,...pmDelayedScripts.async].forEach(function(t){var r=t.getAttribute("src");if(r){var n=document.createElement("link");n.href=r,n.rel="preload",n.as="script",e.appendChild(n)}}),document.head.appendChild(e)}async function pmLoadDelayedScripts(e){var t=e.shift();return t?(await pmReplaceScript(t),pmLoadDelayedScripts(e)):Promise.resolve()}async function pmReplaceScript(e){return await pmNextFrame(),new Promise(function(t){let r=document.createElement("script");[...e.attributes].forEach(function(e){let t=e.nodeName;"type"!==t&&("data-type"===t&&(t="type"),r.setAttribute(t,e.nodeValue))}),e.hasAttribute("src")?(r.addEventListener("load",t),r.addEventListener("error",t)):(r.text=e.text,t()),e.parentNode.replaceChild(r,e)})}async function pmTriggerEventListeners(){pmDOMLoaded=!0,await pmNextFrame(),document.dispatchEvent(new Event("perfmatters-DOMContentLoaded")),await pmNextFrame(),window.dispatchEvent(new Event("perfmatters-DOMContentLoaded")),await pmNextFrame(),document.dispatchEvent(new Event("perfmatters-readystatechange")),await pmNextFrame(),document.perfmattersonreadystatechange&&document.perfmattersonreadystatechange(),await pmNextFrame(),window.dispatchEvent(new Event("perfmatters-load")),await pmNextFrame(),window.perfmattersonload&&window.perfmattersonload(),await pmNextFrame(),jQueriesArray.forEach(function(e){e(window).trigger("perfmatters-jquery-load")});let e=new Event("perfmatters-pageshow");e.persisted=window.pmPersisted,window.dispatchEvent(e),await pmNextFrame(),window.perfmattersonpageshow&&window.perfmattersonpageshow({persisted:window.pmPersisted})}async function pmNextFrame(){return new Promise(function(e){requestAnimationFrame(e)})}function pmClickHandler(e){e.target.removeEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"pm-onclick","onclick"),pmInterceptedClicks.push(e),e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation()}function pmReplayClicks(){window.removeEventListener("touchstart",pmTouchStartHandler,{passive:!0}),window.removeEventListener("mousedown",pmTouchStartHandler),pmInterceptedClicks.forEach(e=>{e.target.outerHTML===pmClickTarget&&e.target.dispatchEvent(new MouseEvent("click",{view:e.view,bubbles:!0,cancelable:!0}))})}function pmTouchStartHandler(e){"HTML"!==e.target.tagName&&(pmClickTarget||(pmClickTarget=e.target.outerHTML),window.addEventListener("touchend",pmTouchEndHandler),window.addEventListener("mouseup",pmTouchEndHandler),window.addEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.addEventListener("mousemove",pmTouchMoveHandler),e.target.addEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"onclick","pm-onclick"))}function pmTouchMoveHandler(e){window.removeEventListener("touchend",pmTouchEndHandler),window.removeEventListener("mouseup",pmTouchEndHandler),window.removeEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",pmTouchMoveHandler),e.target.removeEventListener("click",pmClickHandler),pmRenameDOMAttribute(e.target,"pm-onclick","onclick")}function pmTouchEndHandler(e){window.removeEventListener("touchend",pmTouchEndHandler),window.removeEventListener("mouseup",pmTouchEndHandler),window.removeEventListener("touchmove",pmTouchMoveHandler,{passive:!0}),window.removeEventListener("mousemove",pmTouchMoveHandler)}function pmRenameDOMAttribute(e,t,r){e.hasAttribute&&e.hasAttribute(t)&&(event.target.setAttribute(r,event.target.getAttribute(t)),event.target.removeAttribute(t))}window.addEventListener("pageshow",e=>{window.pmPersisted=e.persisted}),pmUserInteractions.forEach(function(e){window.addEventListener(e,pmTriggerDOMListener,{passive:!0})}),pmDelayClick&&(window.addEventListener("touchstart",pmTouchStartHandler,{passive:!0}),window.addEventListener("mousedown",pmTouchStartHandler)),document.addEventListener("visibilitychange",pmTriggerDOMListener);</script><script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="9bc86d40bf7b88106938a260-|49" defer=""></script>





</div>

<?php get_footer(); ?>