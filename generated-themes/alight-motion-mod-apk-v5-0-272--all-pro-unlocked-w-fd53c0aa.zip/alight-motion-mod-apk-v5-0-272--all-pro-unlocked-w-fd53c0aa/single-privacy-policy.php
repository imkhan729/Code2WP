<?php
/**
 * Single post template for Privacy Policy - Alight Motion Mod APKToggle MenuWhatsAppFacebookInstagramTwitterTelegramScroll to topScroll to top
 * Generated from: privacy-policy.html
 */

get_header(); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-meta">
            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
            <span class="author"><?php the_author(); ?></span>
        </div>
    </header>

    <div class="entry-content">
        
	<div class="entry-content-wrap">
		
<div class="entry-content single-content">
	<div class="kb-row-layout-wrap kb-row-layout-id56_d42215-f3 alignnone wp-block-kadence-rowlayout"><div class="kt-row-column-wrap kt-has-1-columns kt-row-layout-equal kt-tab-layout-inherit kt-mobile-layout-row kt-row-valign-top kb-theme-content-width">

<div class="wp-block-kadence-column kadence-column56_fe3017-64"><div class="kt-inside-inner-col">
<h1 class="kt-adv-heading56_db198c-5f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_db198c-5f">Privacy Policy</h1>



<p class="kt-adv-heading56_095a6d-ee wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_095a6d-ee">At alightmotionsapp.com, accessible from <a href="https://alightmotionsapp.com" data-type="link" data-id="alightmotionsapp.com">alightmotionsapp.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by alightmotionsapp.com and how we use it.</p>



<p class="kt-adv-heading56_402c9b-6d wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_402c9b-6d">If you have additional questions or require more information about our Privacy Policy, do not hesitate to <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>.</p>



<p class="kt-adv-heading56_030e19-a1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_030e19-a1">This Privacy Policy applies only to our online activities and is valid for visitors to our website regarding the information that they share and/or collect on alightmotionsapp.com. It is not applicable to any information collected offline or via channels other than this website.</p>



<h2 class="kt-adv-heading56_ae1166-b0 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_ae1166-b0">Consent</h2>



<p class="kt-adv-heading56_4afae0-34 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_4afae0-34">By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.</p>



<h2 class="kt-adv-heading56_60136b-18 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_60136b-18">Information we collect</h2>



<p class="kt-adv-heading56_3b29ae-b1 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_3b29ae-b1">When you provide personal information, such as your name and address, it will be made evident to you why this information is being collected and how it will be used. ⁤</p>



<p class="kt-adv-heading56_7ba605-38 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_7ba605-38">⁤When you <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>, there is a good chance that we will acquire additional information about you such as your name, email address, phone number, and the messages and their attachments, as well as any other information that you may wish to share. ⁤</p>



<p class="kt-adv-heading56_c19360-7f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_c19360-7f">⁤When you sign up for an Account, we may require you to give your contact details, which can include: name, company name, address, e-mail address, and telephone number</p>



<h2 class="kt-adv-heading56_0d5fd9-4c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_0d5fd9-4c"><strong>How we use your information</strong></h2>



<ul class="wp-block-list">
<li>Manage, Provide, and maintain our site.</li>



<li>Keep improving, personalizing, and expanding our website.</li>



<li>Learning and bringing to light how you use our website.</li>



<li>Develop new products, services, features and functions.</li>



<li>I will talk with you, either directly or through a partner, which may include customer service updates and other website-related information. This may also be used for marketing and promotional purposes.</li>



<li>Send you emails.</li>



<li>Find and prevent fraud.</li>
</ul>



<h2 class="kt-adv-heading56_5d9144-dc wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_5d9144-dc">Log Files</h2>



<p class="kt-adv-heading56_e8e899-2e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_e8e899-2e">alightmotionsapp.com follows a standard procedure of using log files. These files log visitors when they visit websites. All hosting companies do this and are a part of hosting services’ analytics. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. The purpose of the information is to analyze trends, administer the site, track users’ movement on the website, and gather demographic information.</p>



<h2 class="kt-adv-heading56_26fbc7-2f wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_26fbc7-2f">Google DoubleClick DART Cookie</h2>



<p class="kt-adv-heading56_ebdfa1-15 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_ebdfa1-15">Google is one of the third-party vendors on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet. However, visitors may choose to decline the use of DART cookies by visiting the Google ad and content network Privacy Policy at the following URL –&nbsp;<a href="https://policies.google.com/technologies/ads" rel="noopener">https://policies.google.com/technologies/ads</a></p>



<h2 class="kt-adv-heading56_547b79-7a wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_547b79-7a">A<strong>dvertising Partners</strong> Privacy Policies</h2>



<p class="kt-adv-heading56_407f72-cf wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_407f72-cf">You may consult this list to find the Privacy Policy for each of the advertising partners of alightmotionsapp.com.</p>



<p class="kt-adv-heading56_446d95-1c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_446d95-1c">Third-party ad servers or ad networks use technologies like cookies, JavaScript, or Web Beacons in their respective advertisements and links that appear on alightmotionsapp.com. These are sent directly to users’ browsers, and they automatically receive your IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.</p>



<p class="kt-adv-heading56_285cea-6b wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_285cea-6b">Note that alightmotionsapp.com has no access to or control over these cookies that third-party advertisers use.</p>



<h2 class="kt-adv-heading56_4ff1a5-d3 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_4ff1a5-d3">Third Party Privacy Policies</h2>



<p class="kt-adv-heading56_d0fa62-19 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_d0fa62-19">alightmotionsapp.com’s privacy policy does not apply to other advertisers or websites. Thus, we are advising you to consult the respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how to opt out of certain options.</p>



<p class="kt-adv-heading56_125d4b-7c wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_125d4b-7c">You can choose to disable cookies through your individual browser options. More detailed information about cookie management with specific web browsers can be found on their respective websites. What Are Cookies?</p>



<h2 class="kt-adv-heading56_69561c-ff wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_69561c-ff">Children’s Information</h2>



<p class="kt-adv-heading56_9012c0-67 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_9012c0-67">Another part of our priority is protecting children while using the Internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.</p>



<p class="kt-adv-heading56_7f55b3-4e wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_7f55b3-4e">alightmotionsapp.com does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.</p>



<h2 class="kt-adv-heading56_f01fa0-f5 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_f01fa0-f5">Online Privacy Policy Only</h2>



<p class="kt-adv-heading56_d88520-68 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_d88520-68">This Privacy Policy applies only to our online activities and is valid for visitors to our website with regard to the information that they share and/or collect in alightmotionsapp.com. This policy is not applicable to any information collected offline or via channels other than this website.</p>



<h2 class="kt-adv-heading56_69e2dd-e3 wp-block-kadence-advancedheading" data-kb-block="kb-adv-heading56_69e2dd-e3">Contact Us</h2>



<p>If you have any questions about this Privacy Policy, the practices of this Site, or your dealings with this Site, please <a href="https://alightmotionsapp.com/contact-us/" data-type="link" data-id="alightmotionsapp.com/contact-us/">contact us</a>.</p>
</div></div>

</div></div></div><!-- .entry-content -->
	</div>

        <?php the_content(); ?>
    </div>

    <footer class="entry-footer">
        <?php the_tags('<p>Tags: ', ', ', '</p>'); ?>
        <?php the_category(); ?>
    </footer>
</article>

<?php get_footer(); ?>