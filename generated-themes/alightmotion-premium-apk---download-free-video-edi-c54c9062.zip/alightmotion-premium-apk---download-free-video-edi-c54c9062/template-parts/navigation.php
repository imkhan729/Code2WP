<?php
/**
 * Navigation template part
 * Based on original website navigation structure
 */
?>
<nav class="main-navigation" role="navigation">
    <?php
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'menu_class'     => 'primary-menu',
        'container'      => false,
        'walker'         => new Custom_Nav_Walker(),
        'fallback_cb'    => false,
    ));
    ?>
</nav>