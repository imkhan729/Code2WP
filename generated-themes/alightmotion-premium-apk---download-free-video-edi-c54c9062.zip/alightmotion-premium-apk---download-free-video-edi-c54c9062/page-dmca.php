<?php
/**
 * Template for DMCA - AlightMotion Premium APK | Copyright Policy
 * Generated from: dmca.html
 */

get_header(); ?>

<div class="page-content">
    
    <!-- Header -->
    

    <!-- Main Content -->
    <main>
        <!-- Hero Section -->
        <section class="hero" style="padding: 120px 0 80px;">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h1>DMCA Policy</h1>
                    <p>Digital Millennium Copyright Act Compliance</p>
                </div>
            </div>
        </section>

        <!-- DMCA Content -->
        <section class="about" style="padding: 40px 0 80px;">
            <div class="container">
                <div class="about-card">
                    <div class="about-content">
                        <div class="about-description">
                            <h3>DMCA Notice and Takedown Procedure</h3>
                            <p>AlightMotion Premium respects the intellectual property rights of others and expects its users to do the same. We comply with the Digital Millennium Copyright Act (DMCA) and will respond to notices of alleged copyright infringement.</p>
                            
                            <h3>Filing a DMCA Notice</h3>
                            <p>If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement, please provide us with the following information:</p>
                            <ul class="about-feature-list">
                                <li><span>A physical or electronic signature of the copyright owner</span></li>
                                <li><span>Identification of the copyrighted work claimed to have been infringed</span></li>
                                <li><span>Identification of the material that is claimed to be infringing</span></li>
                                <li><span>Your contact information (address, phone number, email)</span></li>
                                <li><span>A statement that you have a good faith belief that use is not authorized</span></li>
                                <li><span>A statement that the information is accurate and you are authorized to act</span></li>
                            </ul>
                            
                            <h3>Counter-Notification</h3>
                            <p>If you believe your content was removed by mistake, you may file a counter-notification containing:</p>
                            <ul class="about-feature-list">
                                <li><span>Your physical or electronic signature</span></li>
                                <li><span>Identification of the removed material and its location</span></li>
                                <li><span>A statement under penalty of perjury that you have a good faith belief</span></li>
                                <li><span>Your consent to local federal court jurisdiction</span></li>
                            </ul>
                            
                            <h3>Repeat Infringers</h3>
                            <p>We maintain a policy of terminating access to our services for users who repeatedly infringe copyrights. We may also terminate access for users who make false claims of copyright infringement.</p>
                            
                            <h3>Contact Information</h3>
                            <p>Please send all DMCA notices and counter-notifications to:</p>
                            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px; margin: 1rem 0;">
                                <p style="margin: 0;"><strong>Email:</strong> dmca@alightmotionpremium.com</p>
                                <p style="margin: 0.5rem 0 0 0;"><strong>Subject Line:</strong> DMCA Notice - [Your Name/Company]</p>
                            </div>
                            
                            <h3>Response Time</h3>
                            <p>We will respond to all valid DMCA notices within 24-48 hours. Upon receiving a valid notice, we will:</p>
                            <ul class="about-feature-list">
                                <li><span>Remove or disable access to the allegedly infringing material</span></li>
                                <li><span>Notify the user who posted the material</span></li>
                                <li><span>Provide information about the takedown</span></li>
                            </ul>
                            
                            <h3>Legal Disclaimer</h3>
                            <p>This DMCA policy is provided for informational purposes only and does not constitute legal advice. If you have questions about copyright law, please consult with a qualified attorney.</p>
                            
                            <h3>Additional Information</h3>
                            <p>For more information about the DMCA, please visit the U.S. Copyright Office website at <a href="https://www.copyright.gov" target="_blank" rel="noopener noreferrer">www.copyright.gov</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    

    <!-- JavaScript -->
    <script src="script.js"></script>



</div>

<?php get_footer(); ?>