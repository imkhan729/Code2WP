<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Download AlightMotion Premium APK - Professional video editing app with premium features unlocked. Create stunning videos with visual effects and animations.">
    <meta name="keywords" content="AlightMotion, video editor, animation app, APK download, premium unlocked, visual effects, vector graphics, mobile video editing">
    <meta name="author" content="AlightMotion Premium">
    <meta name="robots" content="index, follow">
    <meta name="language" content="English">
    <meta name="revisit-after" content="7 days">
    <meta property="og:title" content="AlightMotion Premium APK - Download Free Video Editor">
    <meta property="og:description" content="Download the best mobile video editing and animation app with premium features unlocked. Create professional videos with advanced visual effects.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.alightmotionpremium.com/">
    <meta property="og:image" content="https://www.alightmotionpremium.com/images/Logo.webp">
    <meta property="og:image:width" content="512">
    <meta property="og:image:height" content="512">
    <meta property="og:site_name" content="AlightMotion Premium">
    <meta property="og:locale" content="en_US">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="AlightMotion Premium APK - Download Free Video Editor">
    <meta name="twitter:description" content="Professional video editing and animation app with premium features unlocked.">
    <meta name="twitter:image" content="https://www.alightmotionpremium.com/images/Logo.webp">
    <meta name="twitter:site" content="@Alightmotion111">
    <meta name="theme-color" content="#667eea">
    <meta name="msapplication-TileColor" content="#667eea">
    <meta name="msapplication-config" content="browserconfig.xml">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="header">
        <nav class="navbar">
            <div class="container">
                <a class="nav-brand" href="/" aria-label="AlightMotion Premium APK Home">
                    <img src="images/Logo.webp" alt="AlightMotion Logo" class="logo">
                    <span class="brand-name">AlightMotion Premium APK</span>
                </a>
                <ul id="primary-navigation" class="nav-menu">
                    <li><a href="/">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#download">Download</a></li>   
                    <li><a href="/blog">Blog</a></li>
                </ul>
                <button class="hamburger" type="button" aria-label="Toggle navigation menu" aria-controls="primary-navigation" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </nav>
    </header>
