<?php
/**
 * Category archive template
 * Based on blog pages found in original design
 */

get_header(); ?>

<div class="category-archive">
    <header class="archive-header">
        <h1 class="archive-title"><?php single_cat_title(); ?></h1>
        <?php if (category_description()) : ?>
            <div class="archive-description"><?php echo category_description(); ?></div>
        <?php endif; ?>
    </header>

    <?php if (have_posts()) : ?>
        <div class="posts-grid">
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="post-thumbnail">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    <?php endif; ?>
                    
                    <header class="entry-header">
                        <h2 class="entry-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="entry-meta">
                            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
                        </div>
                    </header>

                    <div class="entry-summary">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <?php the_posts_pagination(); ?>
    <?php else : ?>
        <p><?php _e('No posts found.', 'textdomain'); ?></p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>