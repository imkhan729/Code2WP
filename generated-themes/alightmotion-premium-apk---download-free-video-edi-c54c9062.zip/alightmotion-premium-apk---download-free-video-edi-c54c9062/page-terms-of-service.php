<?php
/**
 * Template for Terms of Service - AlightMotion Premium APK | Usage Terms
 * Generated from: terms-of-service.html
 */

get_header(); ?>

<div class="page-content">
    
    <!-- Header -->
    

    <!-- Main Content -->
    <main>
        <!-- Hero Section -->
        <section class="hero" style="padding: 120px 0 80px;">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h1>Terms of Service</h1>
                    <p>Last updated: August 11, 2024</p>
                </div>
            </div>
        </section>

        <!-- Terms of Service Content -->
        <section class="about" style="padding: 40px 0 80px;">
            <div class="container">
                <div class="about-card">
                    <div class="about-content">
                        <div class="about-description">
                            <h3>Acceptance of Terms</h3>
                            <p>By downloading, installing, or using AlightMotion Premium APK, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our application.</p>
                            
                            <h3>Description of Service</h3>
                            <p>AlightMotion Premium is a modified version of the AlightMotion application that provides enhanced features and unlocked premium content for video editing and animation purposes.</p>
                            
                            <h3>User Responsibilities</h3>
                            <p>As a user of our application, you agree to:</p>
                            <ul class="about-feature-list">
                                <li><span>Use the app only for lawful purposes</span></li>
                                <li><span>Respect intellectual property rights</span></li>
                                <li><span>Not distribute or redistribute the app</span></li>
                                <li><span>Not attempt to reverse engineer the app</span></li>
                                <li><span>Not use the app for commercial purposes without permission</span></li>
                            </ul>
                            
                            <h3>Intellectual Property</h3>
                            <p>AlightMotion Premium APK is provided for educational and personal use only. The original AlightMotion application and its trademarks belong to their respective owners. We do not claim ownership of the original application.</p>
                            
                            <h3>Disclaimer of Warranties</h3>
                            <p>The application is provided "as is" without any warranties, express or implied. We do not guarantee that the app will be error-free, secure, or meet your specific requirements.</p>
                            
                            <h3>Limitation of Liability</h3>
                            <p>In no event shall we be liable for any indirect, incidental, special, consequential, or punitive damages arising out of or relating to your use of the application.</p>
                            
                            <h3>Prohibited Uses</h3>
                            <p>You may not:</p>
                            <ul class="about-feature-list">
                                <li><span>Use the app for illegal activities</span></li>
                                <li><span>Distribute copyrighted content without permission</span></li>
                                <li><span>Attempt to gain unauthorized access to systems</span></li>
                                <li><span>Interfere with the app's functionality</span></li>
                                <li><span>Use the app to harm others or their property</span></li>
                            </ul>
                            
                            <h3>Updates and Modifications</h3>
                            <p>We may update these Terms of Service from time to time. Continued use of the application after changes constitutes acceptance of the new terms.</p>
                            
                            <h3>Termination</h3>
                            <p>We reserve the right to terminate or suspend access to our application at any time, without prior notice, for conduct that we believe violates these Terms of Service or is harmful to other users or us.</p>
                            
                            <h3>Governing Law</h3>
                            <p>These Terms of Service shall be governed by and construed in accordance with the laws of the jurisdiction in which you reside.</p>
                            
                            <h3>Contact Information</h3>
                            <p>If you have any questions about these Terms of Service, please contact us through our social media channels.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    

    <!-- JavaScript -->
    <script src="script.js"></script>



</div>

<?php get_footer(); ?>