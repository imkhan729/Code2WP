<?php get_header(); ?>

<div class="blog-content">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <div class="entry-meta">
                    <time class="entry-date"><?php echo get_the_date(); ?></time>
                    <span class="entry-author"><?php the_author(); ?></span>
                </div>
            </header>
            
            <div class="entry-content">
                
    

    <main>
        <section class="blog-hero">
            <div class="container">
                <div class="section-header" style="text-align: center;">
                    <h1>AlightMotion Blog</h1>
                    <p>Guides, comparisons, and workflow ideas for faster, better edits</p>
                </div>
            </div>
        </section>

        <section class="about" style="padding: 0 0 80px;">
            <div class="container">
                <div class="blog-grid">
                    <!-- New: Presets how-to -->
                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/visual-effects.webp" alt="How to use AlightMotion presets">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Guide</span>
                            <span class="badge badge-outline">Presets</span>
                            <span class="blog-date">Aug 12, 2025</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>How to Use AlightMotion Presets (Step-by-Step)</h2>
                                <p>Learn a fast preset workflow, how to stack looks, and how to make reusable custom presets for consistent results.</p>
                                 <a class="btn btn-secondary" href="/blog/how-to-use-presets-in-alightmotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <!-- New: QR codes how-to -->
                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/parenting.webp" alt="How to use QR Codes in AlightMotion">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Guide</span>
                            <span class="badge badge-outline">QR Codes</span>
                            <span class="blog-date">Aug 12, 2025</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>How to Use QR Codes in AlightMotion</h2>
                                <p>Generate branded QR codes to share projects, preset packs, and tutorials—perfect for platforms with link limits.</p>
                                 <a class="btn btn-secondary" href="/blog/how-to-use-qr-codes-in-alightmotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <!-- New: Import XML -->
                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/keyframe-animation.webp" alt="Import XML in AlightMotion">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Guide</span>
                            <span class="badge badge-outline">XML</span>
                            <span class="blog-date">Aug 12, 2025</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>How to Import XML Files in AlightMotion</h2>
                                <p>Android/iOS steps plus Google Drive method, with best practices to avoid errors and missing assets.</p>
                                 <a class="btn btn-secondary" href="/blog/how-to-import-xml-in-alightmotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <!-- New: Add Text -->
                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/fonts.webp" alt="Add text in AlightMotion">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Guide</span>
                            <span class="badge badge-outline">Text</span>
                            <span class="blog-date">Aug 12, 2025</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>How to Add Text in AlightMotion</h2>
                                <p>Pick fonts, style captions, animate with keyframes, and export clean titles optimized for social platforms.</p>
                                 <a class="btn btn-secondary" href="/blog/how-to-add-text-in-alightimotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <!-- Existing posts -->
                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/visual-effects.webp" alt="CapCut vs AlightMotion comparison">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Comparison</span>
                            <span class="badge badge-outline">Video Editing</span>
                            <span class="blog-date">Aug 11, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>CapCut vs AlightMotion Premium APK: Which Editor Wins?</h2>
                                <p>We compare UI, effects, animation tools, export quality, and ideal use‑cases, so you can pick the right tool.</p>
                                <a class="btn btn-secondary" href="/blog/capcut-vs-alightmotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/color-adjustment.webp" alt="Mobile video editing tips">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-success">Tips &amp; Tricks</span>
                            <span class="badge badge-outline">Tutorial</span>
                            <span class="blog-date">Aug 10, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>10 Pro Tips for Editing with AlightMotion Premium</h2>
                                <p>From mastering keyframes to pro export settings, these tips help you create stunning mobile edits more efficiently.</p>
                                <a class="btn btn-secondary" href="/blog/10-pro-tips-alightmotion">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/vector-graphics.webp" alt="Future of mobile video editing">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-primary">Industry</span>
                            <span class="badge badge-outline">Trends</span>
                            <span class="blog-date">Aug 9, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>The Future of Mobile Video Editing</h2>
                                <p>AI, 5G, and AR are reshaping creative workflows. Here's why AlightMotion Premium is ready for what's next.</p>
                                <a class="btn btn-secondary" href="/blog/future-of-mobile-video-editing">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/keyframe-animation.webp" alt="AlightMotion Mod APK download guide">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-success">Guide</span>
                            <span class="badge badge-outline">Download</span>
                            <span class="blog-date">Aug 8, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>AlightMotion Mod APK Download – Safe &amp; Fast</h2>
                                <p>Get the latest premium build with no watermark and all effects unlocked, plus quick install steps and FAQs.</p>
                                <a class="btn btn-secondary" href="/blog/alightmotion-mod-apk-download">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/aspect-ratio-576x1024.webp" alt="AlightMotion for iOS">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-outline">iOS</span>
                            <span class="badge badge-primary">Guide</span>
                            <span class="blog-date">Aug 7, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>AlightMotion for iOS – Install Methods &amp; Best Alternatives</h2>
                                <p>Understand current availability, AltStore steps, and the top native iOS editors that match AlightMotion.</p>
                                <a class="btn btn-secondary" href="/blog/alightmotion-for-ios">Read Article</a>
                            </div>
                        </div>
                    </article>

                    <article class="about-card blog-card">
                        <div class="card-media">
                            <img class="cover" src="images/parenting.webp" alt="AlightMotion for PC using emulators">
                        </div>
                        <div class="blog-meta">
                            <span class="badge badge-outline">PC</span>
                            <span class="badge badge-primary">Setup</span>
                            <span class="blog-date">Aug 6, 2024</span>
                        </div>
                        <div class="about-content">
                            <div class="about-description">
                                <h2>AlightMotion for PC (Windows/Mac) – Emulator Setup</h2>
                                <p>Run AlightMotion on your computer with BlueStacks or LDPlayer. Full step‑by‑step setup and optimization tips.</p>
                                <a class="btn btn-secondary" href="/blog/alightmotion-for-pc">Read Article</a>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>
    </main>

    

    <script src="script.js"></script>



                <?php the_content(); ?>
            </div>
            
            <footer class="entry-footer">
                <?php the_tags('<div class="tags">', ', ', '</div>'); ?>
                <?php the_category(', '); ?>
            </footer>
        </article>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>