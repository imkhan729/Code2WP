<?php get_header(); ?>

<div class="page-content">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>
            
            
    <!-- @COMPONENT: Header Navigation -->
    
    <!-- @END_COMPONENT: Header Navigation -->

    <!-- @COMPONENT: Main Application Interface -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"><!--?php the_content(); ?--></main>

    <!-- @COMPONENT: Footer -->
    
    <!-- @END_COMPONENT: Footer -->

    <script>
        // Tab switching functionality
        (function() {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const targetTab = this.getAttribute('data-tab');

                    // Remove active class from all buttons
                    tabButtons.forEach(btn => {
                        btn.classList.remove('active', 'border-primary', 'text-primary');
                        btn.classList.add('border-transparent', 'text-gray-500');
                    });

                    // Add active class to clicked button
                    this.classList.add('active', 'border-primary', 'text-primary');
                    this.classList.remove('border-transparent', 'text-gray-500');

                    // Hide all tab contents
                    tabContents.forEach(content => {
                        content.classList.add('hidden');
                    });

                    // Show target tab content
                    const targetContent = document.getElementById(targetTab + '-tab');
                    if (targetContent) {
                        targetContent.classList.remove('hidden');
                    }
                });
            });

            // File drop zone interaction
            const dropZone = document.querySelector('[data-implementation="Implement file drop zone"]');
            if (dropZone) {
                dropZone.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('border-primary', 'bg-blue-50');
                });

                dropZone.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    this.classList.remove('border-primary', 'bg-blue-50');
                });

                dropZone.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('border-primary', 'bg-blue-50');
                    // TODO: Implement file handling logic
                    console.log('Files dropped:', e.dataTransfer.files);
                });
            }
        })();
    </script>


        </article>
    <?php endwhile; ?>
</div>

<?php get_footer(); ?>