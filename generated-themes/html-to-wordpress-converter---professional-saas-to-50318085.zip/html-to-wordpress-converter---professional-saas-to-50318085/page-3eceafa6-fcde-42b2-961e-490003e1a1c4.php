<?php
/**
 * Template for HTML to WordPress Converter - Professional SaaS Tool
 * Generated from: SiteTransform/.local/state/replit/agent/design_reference/334a5324-ef8c-4071-b303-0b8a1458a1b3/3eceafa6-fcde-42b2-961e-490003e1a1c4.html
 */

get_header(); ?>

<div class="page-content">
    
    <!-- @COMPONENT: Header Navigation -->
    
    <!-- @END_COMPONENT: Header Navigation -->

    <!-- @COMPONENT: Main Application Interface -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Hero Section -->
        <div class="text-center mb-12">
            <h2 class="text-4xl font-bold text-gray-900 mb-4">Convert HTML to WordPress</h2>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto">
                Transform your static HTML, CSS, and JavaScript websites into fully functional WordPress themes. 
                Preserve design, responsiveness, and functionality.
            </p>
        </div>

        <!-- @COMPONENT: Conversion Workflow -->
        <div class="grid lg:grid-cols-3 gap-8 mb-12">
            <!-- Step 1: Upload -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center mb-4">
                    <div class="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">1</div>
                    <h3 class="text-lg font-semibold text-gray-900">Upload or Enter URL</h3>
                </div>
                
                <!-- Tab Navigation -->
                <div class="flex border-b border-gray-200 mb-6">
                    <button data-tab="upload" class="tab-button active flex items-center px-4 py-2 text-sm font-medium border-b-2 border-primary text-primary">
                        <i class="fas fa-upload mr-2"></i>Upload Files
                    </button>
                    <button data-tab="url" class="tab-button flex items-center px-4 py-2 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700">
                        <i class="fas fa-link mr-2"></i>Enter URL
                    </button>
                </div>

                <!-- Upload Tab -->
                <div id="upload-tab" class="tab-content">
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer" data-implementation="Implement file drop zone">
                        <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                        <p class="text-lg font-medium text-gray-900 mb-2">Drop your ZIP file here</p>
                        <p class="text-sm text-gray-500 mb-4">or click to browse files</p>
                        <button class="bg-primary text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Choose File
                        </button>
                        <p class="text-xs text-gray-400 mt-4">Supports ZIP files up to 50MB</p>
                    </div>
                </div>

                <!-- URL Tab -->
                <div id="url-tab" class="tab-content hidden">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Website URL</label>
                            <input type="url" placeholder="https://example.com" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" data-implementation="URL validation and parsing">
                        </div>
                        <button class="w-full bg-primary text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Analyze Website
                        </button>
                    </div>
                </div>
            </div>

            <!-- Step 2: Process -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center mb-4">
                    <div class="w-8 h-8 bg-gray-300 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">2</div>
                    <h3 class="text-lg font-semibold text-gray-900">Processing</h3>
                </div>
                
                <!-- Processing Steps -->
                <div class="space-y-4">
                    <div class="flex items-center text-sm text-gray-500" data-mock="true">
                        <i class="fas fa-check-circle text-accent mr-3"></i>
                        <span>Files extracted successfully</span>
                    </div>
                    <div class="flex items-center text-sm text-gray-500" data-mock="true">
                        <i class="fas fa-spinner fa-spin text-warning mr-3"></i>
                        <span>Parsing HTML structure...</span>
                    </div>
                    <div class="flex items-center text-sm text-gray-300" data-mock="true">
                        <i class="far fa-circle mr-3"></i>
                        <span>Converting to WordPress theme</span>
                    </div>
                    <div class="flex items-center text-sm text-gray-300" data-mock="true">
                        <i class="far fa-circle mr-3"></i>
                        <span>Optimizing assets</span>
                    </div>
                </div>

                <!-- Progress Bar -->
                <div class="mt-6">
                    <div class="flex justify-between text-sm text-gray-600 mb-2">
                        <span>Converting...</span>
                        <span data-bind="progress.percentage">35%</span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="bg-primary h-2 rounded-full transition-all duration-300" style="width: 35%" data-bind="progress.width"></div>
                    </div>
                </div>
            </div>

            <!-- Step 3: Download -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div class="flex items-center mb-4">
                    <div class="w-8 h-8 bg-gray-300 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">3</div>
                    <h3 class="text-lg font-semibold text-gray-900">Download Theme</h3>
                </div>
                
                <div class="text-center py-8">
                    <i class="fas fa-download text-4xl text-gray-400 mb-4"></i>
                    <p class="text-gray-500 mb-6">Your WordPress theme will be ready for download once processing is complete.</p>
                    <button class="bg-gray-300 text-gray-500 px-6 py-2 rounded-lg cursor-not-allowed" disabled="">
                        Download Theme
                    </button>
                </div>
            </div>
        </div>
        <!-- @END_COMPONENT: Conversion Workflow -->

        <!-- @COMPONENT: Preview Section -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-xl font-semibold text-gray-900">Live Preview</h3>
                <div class="flex items-center space-x-4">
                    <div class="flex border border-gray-300 rounded-lg">
                        <button class="px-3 py-1 text-sm bg-primary text-white rounded-l-lg">
                            <i class="fas fa-desktop"></i>
                        </button>
                        <button class="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50">
                            <i class="fas fa-tablet-alt"></i>
                        </button>
                        <button class="px-3 py-1 text-sm text-gray-600 hover:bg-gray-50 rounded-r-lg">
                            <i class="fas fa-mobile-alt"></i>
                        </button>
                    </div>
                    <button class="text-gray-600 hover:text-gray-900">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </button>
                </div>
            </div>
            
            <div class="border border-gray-200 rounded-lg bg-gray-100 p-4 min-h-96">
                <div class="text-center py-16">
                    <i class="fas fa-eye text-4xl text-gray-400 mb-4"></i>
                    <p class="text-gray-500">Preview will appear here once your files are processed</p>
                </div>
            </div>
        </div>
        <!-- @END_COMPONENT: Preview Section -->

        <!-- @COMPONENT: Recent Conversions -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 class="text-xl font-semibold text-gray-900 mb-6">Recent Conversions</h3>
            
            <!-- @MAP: recentConversions.map(conversion => ( -->
            <div class="space-y-4">
                <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors" data-mock="true">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-file-archive text-primary text-xl"></i>
                        <div>
                            <h4 class="font-medium text-gray-900" data-bind="conversion.name">portfolio-website.zip</h4>
                            <p class="text-sm text-gray-500" data-bind="conversion.date">Converted 2 hours ago</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <i class="fas fa-check-circle mr-1"></i>
                            Complete
                        </span>
                        <button class="text-primary hover:text-blue-700">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors" data-mock="true">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-link text-primary text-xl"></i>
                        <div>
                            <h4 class="font-medium text-gray-900" data-bind="conversion.name">business-landing.com</h4>
                            <p class="text-sm text-gray-500" data-bind="conversion.date">Converted yesterday</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <i class="fas fa-check-circle mr-1"></i>
                            Complete
                        </span>
                        <button class="text-primary hover:text-blue-700">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors" data-mock="true">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-file-archive text-primary text-xl"></i>
                        <div>
                            <h4 class="font-medium text-gray-900" data-bind="conversion.name">ecommerce-template.zip</h4>
                            <p class="text-sm text-gray-500" data-bind="conversion.date">Failed - 3 days ago</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            <i class="fas fa-exclamation-circle mr-1"></i>
                            Failed
                        </span>
                        <button class="text-primary hover:text-blue-700">
                            <i class="fas fa-redo"></i>
                        </button>
                    </div>
                </div>
            </div>
            <!-- @END_MAP )) -->
        </div>
        <!-- @END_COMPONENT: Recent Conversions -->
    </main>

    <!-- @COMPONENT: Footer -->
    
    <!-- @END_COMPONENT: Footer -->

    <script>
        // Tab switching functionality
        (function() {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const targetTab = this.getAttribute('data-tab');

                    // Remove active class from all buttons
                    tabButtons.forEach(btn => {
                        btn.classList.remove('active', 'border-primary', 'text-primary');
                        btn.classList.add('border-transparent', 'text-gray-500');
                    });

                    // Add active class to clicked button
                    this.classList.add('active', 'border-primary', 'text-primary');
                    this.classList.remove('border-transparent', 'text-gray-500');

                    // Hide all tab contents
                    tabContents.forEach(content => {
                        content.classList.add('hidden');
                    });

                    // Show target tab content
                    const targetContent = document.getElementById(targetTab + '-tab');
                    if (targetContent) {
                        targetContent.classList.remove('hidden');
                    }
                });
            });

            // File drop zone interaction
            const dropZone = document.querySelector('[data-implementation="Implement file drop zone"]');
            if (dropZone) {
                dropZone.addEventListener('dragover', function(e) {
                    e.preventDefault();
                    this.classList.add('border-primary', 'bg-blue-50');
                });

                dropZone.addEventListener('dragleave', function(e) {
                    e.preventDefault();
                    this.classList.remove('border-primary', 'bg-blue-50');
                });

                dropZone.addEventListener('drop', function(e) {
                    e.preventDefault();
                    this.classList.remove('border-primary', 'bg-blue-50');
                    // TODO: Implement file handling logic
                    console.log('Files dropped:', e.dataTransfer.files);
                });
            }
        })();
    </script>


</div>

<?php get_footer(); ?>